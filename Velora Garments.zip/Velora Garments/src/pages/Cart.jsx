import { Link } from "react-router-dom";
import PageShell from "../components/PageShell";
import { Amount } from "../components/ProductCard";
import { MAX_QTY, useCart } from "../context/CartContext";
import { site } from "../data/site";

// Classic WooCommerce cart table + cart totals.
export default function Cart() {
  const { items, removeFromCart, updateQty, subtotal } = useCart();

  if (items.length === 0) {
    return (
      <PageShell title="Cart">
        <div className="woocommerce">
          <div className="wc-empty-cart-message">
            <div className="cart-empty woocommerce-info">Your cart is currently empty.</div>
          </div>
          <p className="return-to-shop">
            <Link className="button wc-backward" to="/shop">Return to shop</Link>
          </p>
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell title="Cart">
      <div className="woocommerce">
        <div className="woocommerce-notices-wrapper">
          {items.some((i) => i.qty >= MAX_QTY) && (
            <div className="woocommerce-info">
              Maximum quantity per item is {MAX_QTY}. For bulk orders, email <a href={site.mailto}>{site.email}</a>.
            </div>
          )}
        </div>
        <form className="woocommerce-cart-form" onSubmit={(e) => e.preventDefault()}>
          <table className="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellSpacing="0">
            <thead>
              <tr>
                <th className="product-remove"><span className="screen-reader-text">Remove item</span></th>
                <th className="product-thumbnail"><span className="screen-reader-text">Thumbnail image</span></th>
                <th className="product-name">Product</th>
                <th className="product-price">Price</th>
                <th className="product-quantity">Quantity</th>
                <th className="product-subtotal">Subtotal</th>
              </tr>
            </thead>
            <tbody>
              {items.map(({ key, product, size, price, qty }) => (
                <tr key={key} className="woocommerce-cart-form__cart-item cart_item">
                  <td className="product-remove">
                    <a
                      href="#"
                      className="remove"
                      aria-label={`Remove ${product.name} from cart`}
                      onClick={(e) => {
                        e.preventDefault();
                        removeFromCart(key);
                      }}
                    >
                      ×
                    </a>
                  </td>
                  <td className="product-thumbnail">
                    <Link to={`/product/${product.pid}`}>
                      <img width="300" height="300" src={product.thumb || product.image} className="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt={product.name} />
                    </Link>
                  </td>
                  <td className="product-name" data-title="Product">
                    <Link to={`/product/${product.pid}`}>{product.name}{size && ` - ${size}`}</Link>
                    {size && (
                      <dl className="variation">
                        <dt className="variation-Size">Size:</dt>
                        <dd className="variation-Size"><p>{size}</p></dd>
                      </dl>
                    )}
                  </td>
                  <td className="product-price" data-title="Price">
                    <Amount value={price} />
                  </td>
                  <td className="product-quantity" data-title="Quantity">
                    <div className="quantity">
                      <input
                        type="number"
                        className="input-text qty text"
                        value={qty}
                        min="1"
                        max={MAX_QTY}
                        step="1"
                        aria-label="Product quantity"
                        onChange={(e) => updateQty(key, Number(e.target.value) || 1)}
                      />
                    </div>
                  </td>
                  <td className="product-subtotal" data-title="Subtotal">
                    <Amount value={price * qty} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </form>

        <div className="cart-collaterals">
          <div className="cart_totals">
            <h2>Cart totals</h2>
            <table cellSpacing="0" className="shop_table shop_table_responsive">
              <tbody>
                <tr className="cart-subtotal">
                  <th>Subtotal</th>
                  <td data-title="Subtotal"><Amount value={subtotal} /></td>
                </tr>
                <tr className="order-total">
                  <th>Total</th>
                  <td data-title="Total"><strong><Amount value={subtotal} /></strong></td>
                </tr>
              </tbody>
            </table>
            <div className="wc-proceed-to-checkout">
              <Link to="/checkout" className="checkout-button button alt wc-forward">Proceed to checkout</Link>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
