import { Link } from "react-router-dom";
import PageShell from "../components/PageShell";
import { site } from "../data/site";

export default function About() {
  return (
    <PageShell title="About Us">
      <figure className="wp-block-gallery has-nested-images columns-default is-cropped wp-block-gallery-1 is-layout-flex wp-block-gallery-is-layout-flex">
        <figure className="wp-block-image size-full">
          <img width="2560" height="1579" src="/img/wp/about.webp" alt="" />
        </figure>
      </figure>
      <p>
        Velora Garments is an India-based clothing brand dedicated to bringing you comfortable, stylish, and
        affordable apparel for the whole family — men, women, and kids.
      </p>
      <h2>Our Story</h2>
      <p>
        Founded with a passion for everyday fashion, Velora Garments curates quality garments that blend modern
        design with everyday comfort. From wardrobe essentials to statement pieces, we believe great style should be
        accessible to everyone.
      </p>
      <h2>What We Offer</h2>
      <ul>
        <li><strong>Men’s Wear</strong> — T-shirts, shirts, and more.</li>
        <li><strong>Women’s Wear</strong> — kurtis, tops, dresses, and ethnic styles.</li>
        <li><strong>Kids’ Wear</strong> — playful, comfortable clothing for little ones.</li>
      </ul>
      <h2>Our Promise</h2>
      <p>
        Quality fabrics, honest pricing in Indian Rupees, secure checkout, and reliable delivery across India. Your
        satisfaction is at the heart of everything we do.
      </p>
      <h2>Get in Touch</h2>
      <p>
        Have a question? We’d love to hear from you. Visit our <Link to="/contact-us">Contact page</Link> or email us
        at <a href={site.mailto}>{site.email}</a>.
      </p>
    </PageShell>
  );
}
