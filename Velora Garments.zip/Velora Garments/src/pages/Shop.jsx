import { useMemo } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { ProductGrid } from "../components/ProductCard";
import { categories, products } from "../data/products";

const PER_PAGE = 12;

// Live store's "Default sorting" is alphabetical by slug.
const byName = (a, b) => a.pid.localeCompare(b.pid);
const sorters = {
  menu_order: byName,
  popularity: byName,
  rating: byName,
  date: (a, b) => b.wcId - a.wcId,
  price: (a, b) => a.price - b.price || byName(a, b),
  "price-desc": (a, b) => b.maxPrice - a.maxPrice || byName(a, b),
};

// Serves /shop, /shop/page/:page, /product-category/:cat (same URLs as the live store).
export default function Shop() {
  const { cat, sub, page: pageParam } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const search = (searchParams.get("s") || "").toLowerCase();
  const orderby = sorters[searchParams.get("orderby")] ? searchParams.get("orderby") : "menu_order";

  const activeCategory = categories.find((c) => c.id === cat);
  // Sub-categories (e.g. /product-category/kids/girls) come from each product's WooCommerce categories.
  const subCategory = sub
    ? products.flatMap((p) => p.cats || []).find((c) => c.path === `/product-category/${cat}/${sub}`)
    : null;
  const base = subCategory ? subCategory.path : activeCategory ? `/product-category/${activeCategory.id}` : "/shop";
  const title = subCategory ? subCategory.name : activeCategory ? activeCategory.name : "Shop";

  const filtered = useMemo(
    () =>
      products
        .filter((p) => (activeCategory ? p.categoryId === activeCategory.id : true))
        .filter((p) => (subCategory ? (p.cats || []).some((c) => c.path === subCategory.path) : true))
        .filter((p) => (search ? `${p.name} ${p.subCategory}`.toLowerCase().includes(search) : true))
        .sort(sorters[orderby]),
    [activeCategory, subCategory, search, orderby]
  );

  const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const page = Math.min(Math.max(1, Number(pageParam) || 1), pages);
  const shown = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);
  const qs = searchParams.toString() ? `?${searchParams}` : "";
  const pageUrl = (n) => `${base}${n > 1 ? `/page/${n}` : ""}${qs}`;

  const onSort = (e) => {
    const next = new URLSearchParams(searchParams);
    next.set("orderby", e.target.value);
    navigate(`${base}?${next}`);
  };

  const first = (page - 1) * PER_PAGE + 1;
  const last = first + shown.length - 1;

  return (
    <div className="ast-container">
      <div id="primary" className="content-area primary">
        <main id="main" className="site-main">
          <div className="ast-woocommerce-container">
            <nav className="woocommerce-breadcrumb" aria-label="Breadcrumb">
              <Link to="/">Home</Link>
              {subCategory && activeCategory && (
                <>&nbsp;/&nbsp;<Link to={`/product-category/${activeCategory.id}`}>{activeCategory.name}</Link></>
              )}
              &nbsp;/&nbsp;{title}
            </nav>
            <header className="woocommerce-products-header">
              <h1 className="woocommerce-products-header__title page-title">
                {search ? `Search results: “${searchParams.get("s")}”` : title}
              </h1>
            </header>
            <div className="woocommerce-notices-wrapper"></div>

            {filtered.length === 0 ? (
              <div className="woocommerce-info woocommerce-no-products-found">
                No products were found matching your selection.
              </div>
            ) : (
              <>
                <p className="woocommerce-result-count" role="status">
                  {filtered.length === 1
                    ? "Showing the single result"
                    : pages === 1
                      ? `Showing all ${filtered.length} results`
                      : `Showing ${first}–${last} of ${filtered.length} results`}
                </p>
                <form className="woocommerce-ordering" onSubmit={(e) => e.preventDefault()}>
                  <select name="orderby" className="orderby" aria-label="Shop order" value={orderby} onChange={onSort}>
                    <option value="menu_order">Default sorting</option>
                    <option value="popularity">Sort by popularity</option>
                    <option value="rating">Sort by average rating</option>
                    <option value="date">Sort by latest</option>
                    <option value="price">Sort by price: low to high</option>
                    <option value="price-desc">Sort by price: high to low</option>
                  </select>
                </form>

                <ProductGrid products={shown} />

                {pages > 1 && (
                  <nav className="woocommerce-pagination" aria-label="Product Pagination">
                    <ul className="page-numbers">
                      {page > 1 && (
                        <li>
                          <Link className="prev page-numbers" to={pageUrl(page - 1)}>←</Link>
                        </li>
                      )}
                      {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
                        <li key={n}>
                          {n === page ? (
                            <span aria-current="page" className="page-numbers current">{n}</span>
                          ) : (
                            <Link className="page-numbers" to={pageUrl(n)}>{n}</Link>
                          )}
                        </li>
                      ))}
                      {page < pages && (
                        <li>
                          <Link className="next page-numbers" to={pageUrl(page + 1)}>→</Link>
                        </li>
                      )}
                    </ul>
                  </nav>
                )}
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
