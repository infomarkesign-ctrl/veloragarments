import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Amount, PriceTag, ProductGrid } from "../components/ProductCard";
import { MAX_QTY, useCart } from "../context/CartContext";
import { getProduct, products } from "../data/products";

// Keyed by pid so size/qty state resets when moving to a related product.
export default function ProductDetails() {
  const { pid } = useParams();
  return <ProductView key={pid} pid={pid} />;
}

function CatLinks({ cats }) {
  return cats.map((c, i) => (
    <span key={c.slug}>
      {i > 0 && ", "}
      <Link to={c.path} rel="tag">{c.name}</Link>
    </span>
  ));
}

function ProductView({ pid }) {
  const product = getProduct(pid);
  const { addToCart } = useCart();
  const [qty, setQty] = useState(1);
  const [size, setSize] = useState("");
  const [tab, setTab] = useState("description");
  const [notice, setNotice] = useState(null);

  if (!product) {
    return (
      <div className="ast-container">
        <div id="primary" className="content-area primary">
          <main id="main" className="site-main">
            <div className="woocommerce-info">Product not found. <Link to="/shop">Return to shop</Link></div>
          </main>
        </div>
      </div>
    );
  }

  const cats = product.cats || [];
  const needsSize = product.sizes.length > 0;
  const variant = product.sizes.find((s) => s.size === size);
  const onSale = product.originalPrice > product.price;
  const parent = cats.find((c) => !c.path.slice("/product-category/".length).includes("/"));
  const sub = cats.find((c) => c !== parent);

  const related = products
    .filter((p) => p.pid !== product.pid && p.categoryId === product.categoryId)
    .slice(0, 4);

  const handleAdd = (e) => {
    e.preventDefault();
    if (needsSize && !variant) {
      setNotice({ type: "error", text: "Please select some product options before adding this product to your cart." });
      return;
    }
    const { limited, maxQty } = addToCart(product, size, qty);
    setNotice(
      limited
        ? { type: "error", text: `You cannot add more than ${maxQty} of this item to your cart.` }
        : { type: "message", text: `${qty} × “${product.name}” has been added to your cart.` }
    );
  };

  return (
    <div className="ast-container">
      <div id="primary" className="content-area primary">
        <main id="main" className="site-main">
          <div className="ast-woocommerce-container">
            <div className="woocommerce-notices-wrapper">
              {notice?.type === "message" && (
                <div className="woocommerce-message" role="alert">
                  <Link to="/cart" className="button wc-forward">View cart</Link> {notice.text}
                </div>
              )}
              {notice?.type === "error" && (
                <ul className="woocommerce-error" role="alert">
                  <li>{notice.text}</li>
                </ul>
              )}
            </div>

            <div className={`ast-article-single ast-woo-product-no-review desktop-align-left tablet-align-left mobile-align-left product type-product status-publish first instock has-post-thumbnail ${onSale ? "sale" : ""} purchasable ${needsSize ? "product-type-variable" : "product-type-simple"}`}>
              {onSale && <span className="ast-on-card-button ast-onsale-card">Sale!</span>}
              <div className="woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images">
                <div className="woocommerce-product-gallery__wrapper">
                  <div className="woocommerce-product-gallery__image">
                    <a href={product.image} target="_blank" rel="noreferrer">
                      <img src={product.image} className="wp-post-image" alt={product.name} />
                    </a>
                  </div>
                </div>
              </div>

              <div className="summary entry-summary">
                <nav className="woocommerce-breadcrumb" aria-label="Breadcrumb">
                  <Link to="/">Home</Link>
                  {parent && <>&nbsp;/&nbsp;<Link to={parent.path}>{parent.name}</Link></>}
                  {sub && <>&nbsp;/&nbsp;<Link to={sub.path}>{sub.name}</Link></>}
                  &nbsp;/&nbsp;{product.name}
                </nav>
                <span className="single-product-category">
                  <CatLinks cats={cats} />
                </span>
                <h1 className="product_title entry-title">{product.name}</h1>
                <PriceTag product={product} as="p" />
                <div className="woocommerce-product-details__short-description">
                  <p>{product.short}</p>
                </div>

                <form className={needsSize ? "variations_form cart" : "cart"} onSubmit={handleAdd}>
                  {needsSize && (
                    <>
                      <table className="variations" cellSpacing="0" role="presentation">
                        <tbody>
                          <tr>
                            <th className="label"><label htmlFor="size">Size</label></th>
                            <td className="value">
                              <select
                                id="size"
                                name="attribute_size"
                                value={size}
                                onChange={(e) => {
                                  setSize(e.target.value);
                                  setNotice(null);
                                }}
                              >
                                <option value="">Choose an option</option>
                                {product.sizes.map((s) => (
                                  <option key={s.size} value={s.size}>{s.size}</option>
                                ))}
                              </select>
                              {size && (
                                <a className="reset_variations" href="#" onClick={(e) => { e.preventDefault(); setSize(""); }} style={{ visibility: "visible" }}>
                                  Clear
                                </a>
                              )}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      <div className="single_variation_wrap">
                        <div className="woocommerce-variation single_variation">
                          {variant && (
                            <div className="woocommerce-variation-price">
                              <span className="price">
                                {variant.mrp > variant.price && (
                                  <del aria-hidden="true"><Amount value={variant.mrp} /></del>
                                )}{" "}
                                <ins aria-hidden="true"><Amount value={variant.price} /></ins>
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                  <div className={needsSize ? "woocommerce-variation-add-to-cart variations_button" : ""}>
                    <div className="quantity">
                      <label className="screen-reader-text" htmlFor="quantity">{product.name} quantity</label>
                      <input
                        type="number"
                        id="quantity"
                        className="input-text qty text"
                        name="quantity"
                        value={qty}
                        aria-label="Product quantity"
                        min="1"
                        max={MAX_QTY}
                        step="1"
                        inputMode="numeric"
                        onChange={(e) => setQty(Math.min(MAX_QTY, Math.max(1, Number(e.target.value) || 1)))}
                      />
                    </div>
                    <button
                      type="submit"
                      className={`single_add_to_cart_button button alt${needsSize && !variant ? " disabled wc-variation-selection-needed" : ""}`}
                    >
                      Add to cart
                    </button>
                  </div>
                </form>

                <div className="product_meta">
                  {product.sku && (
                    <span className="sku_wrapper">SKU: <span className="sku">{product.sku}</span></span>
                  )}
                  {cats.length > 0 && (
                    <span className="posted_in">
                      {cats.length > 1 ? "Categories" : "Category"}: <CatLinks cats={cats} />
                    </span>
                  )}
                  {product.tags?.length > 0 && (
                    <span className="tagged_as">
                      {product.tags.length > 1 ? "Tags" : "Tag"}:{" "}
                      {product.tags.map((t, i) => (
                        <span key={t}>
                          {i > 0 && ", "}
                          <Link to={`/shop?s=${encodeURIComponent(t)}`} rel="tag">{t}</Link>
                        </span>
                      ))}
                    </span>
                  )}
                </div>
              </div>

              <div className="woocommerce-tabs wc-tabs-wrapper">
                <ul className="tabs wc-tabs" role="tablist">
                  {[
                    ["description", "Description"],
                    ...(needsSize ? [["additional_information", "Additional information"]] : []),
                    ["reviews", "Reviews (0)"],
                  ].map(([id, label]) => (
                    <li key={id} className={`${id}_tab${tab === id ? " active" : ""}`} role="presentation">
                      <a href={`#tab-${id}`} role="tab" onClick={(e) => { e.preventDefault(); setTab(id); }}>
                        {label}
                      </a>
                    </li>
                  ))}
                </ul>
                {tab === "description" && (
                  <div
                    className="woocommerce-Tabs-panel woocommerce-Tabs-panel--description panel entry-content wc-tab"
                    role="tabpanel"
                    dangerouslySetInnerHTML={{ __html: product.descriptionHtml }}
                  />
                )}
                {tab === "additional_information" && (
                  <div className="woocommerce-Tabs-panel woocommerce-Tabs-panel--additional_information panel entry-content wc-tab" role="tabpanel">
                    <table className="woocommerce-product-attributes shop_attributes" aria-label="Product Details">
                      <tbody>
                        <tr className="woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_size">
                          <th className="woocommerce-product-attributes-item__label" scope="row">Size</th>
                          <td className="woocommerce-product-attributes-item__value">
                            <p>{product.sizes.map((s) => s.size).join(", ")}</p>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                )}
                {tab === "reviews" && (
                  <div className="woocommerce-Tabs-panel woocommerce-Tabs-panel--reviews panel entry-content wc-tab" role="tabpanel">
                    <div id="reviews" className="woocommerce-Reviews">
                      <div id="comments">
                        <h2 className="woocommerce-Reviews-title">Reviews</h2>
                        <p className="woocommerce-noreviews">There are no reviews yet.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {related.length > 0 && (
                <section className="related products">
                  <h2>Related products</h2>
                  <ProductGrid products={related} />
                </section>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
