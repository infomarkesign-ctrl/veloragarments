import { useNavigate } from "react-router-dom";
import PageShell from "../components/PageShell";
import { legalPages } from "../data/legal";

// Renders the legal page content copied from the live site.
export default function LegalPage({ page }) {
  const navigate = useNavigate();
  const { title, html } = legalPages[page];

  // Keep internal links inside the SPA instead of full page reloads.
  const handleClick = (e) => {
    const href = e.target.closest("a")?.getAttribute("href");
    if (href && href.startsWith("/")) {
      e.preventDefault();
      navigate(href);
    }
  };

  return (
    <PageShell title={title}>
      <div onClick={handleClick} dangerouslySetInnerHTML={{ __html: html }} />
    </PageShell>
  );
}
