import { Link } from "react-router-dom";
import { ProductGrid } from "../components/ProductCard";
import { categories, featuredProducts, newArrivals, products } from "../data/products";

// Same block markup as the WordPress home page (cover + headings + Woo shortcodes).
export default function Home() {
  const countFor = (id) => products.filter((p) => p.categoryId === id).length;

  return (
    <div className="ast-container">
      <div id="primary" className="content-area primary">
        <main id="main" className="site-main">
          <article className="page type-page status-publish ast-article-single">
            <header className="entry-header ast-no-thumbnail ast-no-title ast-header-without-markup"></header>
            <div className="entry-content clear" data-ast-blocks-layout="true">
              <div className="wp-block-cover alignfull" style={{ minHeight: 460, aspectRatio: "unset" }}>
                <img
                  width="1024"
                  height="684"
                  className="wp-block-cover__image-background size-large"
                  alt=""
                  src="/img/wp/hero.jpg"
                  data-object-fit="cover"
                />
                <span aria-hidden="true" className="wp-block-cover__background has-black-background-color has-background-dim-60 has-background-dim"></span>
                <div className="wp-block-cover__inner-container is-layout-flow wp-block-cover-is-layout-flow">
                  <h1 className="wp-block-heading has-text-align-center has-text-color" style={{ color: "#ffffff", fontSize: 46 }}>
                    Premium Clothing for Men, Women &amp; Kids
                  </h1>
                  <p className="has-text-align-center has-text-color wp-block-paragraph" style={{ color: "#ffffff" }}>
                    Quality fabrics, honest prices in INR, and fast delivery across India.
                  </p>
                  <div className="wp-block-buttons is-content-justification-center is-layout-flex wp-container-core-buttons-is-layout-3e41869c wp-block-buttons-is-layout-flex">
                    <div className="wp-block-button">
                      <Link className="wp-block-button__link has-black-color has-white-background-color has-text-color has-background wp-element-button" to="/shop">
                        Shop Now
                      </Link>
                    </div>
                  </div>
                </div>
              </div>

              <h2 className="wp-block-heading has-text-align-center">Shop by Category</h2>
              <div className="woocommerce columns-3">
                <ul className="products columns-3">
                  {categories.map((c, i) => (
                    <li
                      key={c.id}
                      className={`product-category product${i === 0 ? " first" : ""}${i === categories.length - 1 ? " last" : ""}`}
                    >
                      <Link aria-label={`Visit product category ${c.name}`} to={`/product-category/${c.id}`}>
                        <img src={c.image} alt={c.name} width="300" height="300" />
                        <h2 className="woocommerce-loop-category__title">
                          {c.name}
                          <mark className="count">{countFor(c.id)} Products</mark>
                        </h2>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              <h2 className="wp-block-heading has-text-align-center">Featured Products</h2>
              <div className="woocommerce columns-4">
                <ProductGrid products={featuredProducts} />
              </div>

              <h2 className="wp-block-heading has-text-align-center">New Arrivals</h2>
              <div className="woocommerce columns-4">
                <ProductGrid products={newArrivals} />
              </div>
            </div>
          </article>
        </main>
      </div>
    </div>
  );
}
