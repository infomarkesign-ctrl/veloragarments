import { useEffect, useRef } from "react";
import { Navigate, useLocation } from "react-router-dom";
import PageShell from "../components/PageShell";
import { Amount } from "../components/ProductCard";
import { useCart } from "../context/CartContext";

// WooCommerce "order received" page layout.
export default function OrderConfirmation() {
  const { state } = useLocation();
  const order = state?.order;
  const { clearCart } = useCart();
  const cleared = useRef(false);

  useEffect(() => {
    if (order && !cleared.current) {
      cleared.current = true;
      clearCart();
    }
  }, [order, clearCart]);

  if (!order) {
    return <Navigate to="/shop" replace />;
  }

  const total = order.total ?? order.subtotal;
  const method = order.shipping.paymentMethod === "cod" ? "Cash on delivery" : "UPI";

  return (
    <PageShell title="Checkout">
      <div className="woocommerce">
        <div className="woocommerce-order">
          <p className="woocommerce-notice woocommerce-notice--success woocommerce-thankyou-order-received">
            Thank you. Your order has been received.
          </p>
          <ul className="woocommerce-order-overview woocommerce-thankyou-order-details order_details">
            <li className="woocommerce-order-overview__order order">Order number: <strong>{order.orderId}</strong></li>
            <li className="woocommerce-order-overview__date date">
              Date: <strong>{new Date(order.placedAt).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</strong>
            </li>
            <li className="woocommerce-order-overview__email email">Email: <strong>{order.shipping.email}</strong></li>
            <li className="woocommerce-order-overview__total total">Total: <strong><Amount value={total} /></strong></li>
            <li className="woocommerce-order-overview__payment-method method">Payment method: <strong>{method}</strong></li>
          </ul>

          <section className="woocommerce-order-details">
            <h2 className="woocommerce-order-details__title">Order details</h2>
            <table className="woocommerce-table woocommerce-table--order-details shop_table order_details">
              <thead>
                <tr>
                  <th className="woocommerce-table__product-name product-name">Product</th>
                  <th className="woocommerce-table__product-table product-total">Total</th>
                </tr>
              </thead>
              <tbody>
                {order.items.map(({ key, product, size, price, qty }) => (
                  <tr key={key} className="woocommerce-table__line-item order_item">
                    <td className="woocommerce-table__product-name product-name">
                      {product.name}{size && ` - ${size}`} <strong className="product-quantity">×&nbsp;{qty}</strong>
                    </td>
                    <td className="woocommerce-table__product-total product-total"><Amount value={price * qty} /></td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <th scope="row">Subtotal:</th>
                  <td><Amount value={order.subtotal} /></td>
                </tr>
                {order.discount && (
                  <tr>
                    <th scope="row">Discount ({order.discount.code}):</th>
                    <td>-<Amount value={order.discount.amount} /></td>
                  </tr>
                )}
                <tr>
                  <th scope="row">Payment method:</th>
                  <td>{method}</td>
                </tr>
                <tr>
                  <th scope="row">Total:</th>
                  <td><Amount value={total} /></td>
                </tr>
              </tfoot>
            </table>
          </section>

          <section className="woocommerce-customer-details">
            <h2 className="woocommerce-column__title">Billing address</h2>
            <address>
              {order.shipping.fullName}
              <br />
              {order.shipping.address}
              <br />
              {order.shipping.city}, {order.shipping.state} {order.shipping.pincode}
              <p className="woocommerce-customer-details--phone">{order.shipping.phone}</p>
              <p className="woocommerce-customer-details--email">{order.shipping.email}</p>
            </address>
          </section>
        </div>
      </div>
    </PageShell>
  );
}
