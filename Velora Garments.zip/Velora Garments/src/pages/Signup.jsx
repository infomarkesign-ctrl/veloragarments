import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PageShell from "../components/PageShell";

export default function Signup() {
  const [signupMethod, setSignupMethod] = useState("email");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const showMessage = (msg, isError = false) => {
    setError(msg);
    setTimeout(() => setError(""), 3000);
  };

  const validatePassword = () => {
    if (password.length < 6) {
      showMessage("Password must be at least 6 characters", true);
      return false;
    }
    if (password !== confirmPassword) {
      showMessage("Passwords do not match", true);
      return false;
    }
    return true;
  };

  const handleSignupEmail = async (e) => {
    e.preventDefault();
    if (!fullName || !email || !password || !confirmPassword) {
      showMessage("Please fill in all required fields", true);
      return;
    }
    if (!validatePassword()) return;

    setLoading(true);
    try {
      const response = await fetch("/api/auth/signup-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName,
          email,
          password,
          phoneNumber: phoneNumber || null,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("userEmail", email);
        showMessage("Account created successfully!");
        setTimeout(() => navigate("/"), 500);
      } else {
        showMessage(data.error || "Signup failed", true);
      }
    } catch (error) {
      showMessage("Something went wrong", true);
    } finally {
      setLoading(false);
    }
  };

  const handleSignupPhone = async (e) => {
    e.preventDefault();
    if (!fullName || !phoneNumber || !password || !confirmPassword) {
      showMessage("Please fill in all required fields", true);
      return;
    }
    if (phoneNumber.length !== 10) {
      showMessage("Phone number must be 10 digits", true);
      return;
    }
    if (!validatePassword()) return;

    setLoading(true);
    try {
      const response = await fetch("/api/auth/signup-phone", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName,
          phoneNumber,
          password,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("userPhone", phoneNumber);
        showMessage("Account created successfully!");
        setTimeout(() => navigate("/"), 500);
      } else {
        showMessage(data.error || "Signup failed", true);
      }
    } catch (error) {
      showMessage("Something went wrong", true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageShell title="Create Account">
      <div className="woocommerce">
        <div className="woocommerce-notices-wrapper">
          {error && (
            <div className={`woocommerce-message ${error.includes("successfully") ? "" : "woocommerce-error"}`}>
              {error}
            </div>
          )}
        </div>

        <div className="u-columns col2-set" id="customer_signup">
          {/* Email Signup */}
          {signupMethod === "email" && (
            <div className="u-column1 col-1">
              <h2>Sign up with Email</h2>
              <form className="woocommerce-form woocommerce-form-register register" onSubmit={handleSignupEmail}>
                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="full_name">Full name&nbsp;<span className="required">*</span></label>
                  <input
                    type="text"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="full_name"
                    id="full_name"
                    placeholder="John Doe"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                  />
                </p>

                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="reg_email">Email address&nbsp;<span className="required">*</span></label>
                  <input
                    type="email"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="email"
                    id="reg_email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </p>

                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="phone">Phone number (optional)</label>
                  <input
                    type="tel"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="phone"
                    id="phone"
                    placeholder="9999999999"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    maxLength={10}
                  />
                </p>

                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="password">Password&nbsp;<span className="required">*</span></label>
                  <input
                    type="password"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="password"
                    id="password"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </p>

                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="confirm_password">Confirm password&nbsp;<span className="required">*</span></label>
                  <input
                    type="password"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="confirm_password"
                    id="confirm_password"
                    placeholder="Confirm password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </p>

                <div className="woocommerce-privacy-policy-text">
                  <p>
                    Your personal data will be used to support your experience throughout this website, to manage access
                    to your account, and for other purposes described in our{" "}
                    <Link to="/privacy-policy" className="woocommerce-privacy-policy-link">privacy policy</Link>.
                  </p>
                </div>

                <p className="woocommerce-form-row form-row">
                  <button type="submit" disabled={loading} className="woocommerce-Button woocommerce-button button woocommerce-form-register__submit">
                    {loading ? "Creating account..." : "Create Account"}
                  </button>
                </p>
              </form>
            </div>
          )}

          {/* Phone Signup */}
          {signupMethod === "phone" && (
            <div className="u-column1 col-1">
              <h2>Sign up with Phone</h2>
              <form className="woocommerce-form woocommerce-form-register register" onSubmit={handleSignupPhone}>
                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="full_name_phone">Full name&nbsp;<span className="required">*</span></label>
                  <input
                    type="text"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="full_name_phone"
                    id="full_name_phone"
                    placeholder="John Doe"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                  />
                </p>

                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="phone_signup">Phone number&nbsp;<span className="required">*</span></label>
                  <input
                    type="tel"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="phone_signup"
                    id="phone_signup"
                    placeholder="9999999999"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    maxLength={10}
                    required
                  />
                </p>

                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="password_phone">Password&nbsp;<span className="required">*</span></label>
                  <input
                    type="password"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="password_phone"
                    id="password_phone"
                    placeholder="Enter password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </p>

                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="confirm_password_phone">Confirm password&nbsp;<span className="required">*</span></label>
                  <input
                    type="password"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="confirm_password_phone"
                    id="confirm_password_phone"
                    placeholder="Confirm password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </p>

                <div className="woocommerce-privacy-policy-text">
                  <p>
                    Your personal data will be used to support your experience throughout this website, to manage access
                    to your account, and for other purposes described in our{" "}
                    <Link to="/privacy-policy" className="woocommerce-privacy-policy-link">privacy policy</Link>.
                  </p>
                </div>

                <p className="woocommerce-form-row form-row">
                  <button type="submit" disabled={loading} className="woocommerce-Button woocommerce-button button woocommerce-form-register__submit">
                    {loading ? "Creating account..." : "Create Account"}
                  </button>
                </p>
              </form>
            </div>
          )}

          <div className="u-column2 col-2">
            <h2>Already have an account?</h2>
            <p>Log in to access your account:</p>
            <Link to="/my-account" className="woocommerce-Button woocommerce-button button">
              Log In
            </Link>
          </div>

          <div style={{ marginTop: "30px", textAlign: "center", width: "100%" }}>
            <h3>Sign up Method</h3>
            <div style={{ display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
              <button
                onClick={() => setSignupMethod("email")}
                className={`woocommerce-button button ${signupMethod === "email" ? "active" : ""}`}
                style={{
                  backgroundColor: signupMethod === "email" ? "#333" : "#ddd",
                  color: signupMethod === "email" ? "#fff" : "#000",
                }}
              >
                Email
              </button>
              <button
                onClick={() => setSignupMethod("phone")}
                className={`woocommerce-button button ${signupMethod === "phone" ? "active" : ""}`}
                style={{
                  backgroundColor: signupMethod === "phone" ? "#333" : "#ddd",
                  color: signupMethod === "phone" ? "#fff" : "#000",
                }}
              >
                Phone
              </button>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
