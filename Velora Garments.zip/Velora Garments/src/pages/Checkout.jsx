import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import PageShell from "../components/PageShell";
import { Amount } from "../components/ProductCard";
import { useCart } from "../context/CartContext";
import { createUpiOrder } from "../services/srpay";

const emptyForm = {
  fullName: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  state: "",
  pincode: "",
  paymentMethod: "cod",
};

export default function Checkout() {
  const { items, subtotal } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState(emptyForm);
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState("");

  if (items.length === 0) {
    return <Navigate to="/cart" replace />;
  }

  const total = subtotal;

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setPlacing(true);

    const orderId = `ORD-${Date.now().toString().slice(-8)}`;
    const order = {
      orderId,
      items,
      subtotal,
      discount: null,
      total,
      shipping: { ...form },
      placedAt: new Date().toISOString(),
    };

    if (form.paymentMethod === "upi") {
      try {
        const upiOrder = await createUpiOrder({
          amount: total,
          name: form.fullName,
          email: form.email,
          mobile: form.phone,
        });
        sessionStorage.setItem(
          "velora_pending_order",
          JSON.stringify({ ...order, srpayOrderId: upiOrder.order_id })
        );
        window.location.href = upiOrder.payment_url;
      } catch (err) {
        setError(err.message || "Payment could not be started. Please try again.");
        setPlacing(false);
      }
      return;
    }

    setTimeout(() => {
      navigate("/order-confirmation", { state: { order } });
    }, 800);
  };

  const field = (name, label, { type = "text", wide = false, first = false, autoComplete } = {}) => (
    <p className={`form-row ${wide ? "form-row-wide" : first ? "form-row-first" : "form-row-last"} validate-required`} id={`${name}_field`}>
      <label htmlFor={name}>
        {label}&nbsp;<abbr className="required" title="required">*</abbr>
      </label>
      <span className="woocommerce-input-wrapper">
        <input
          required
          type={type}
          className="input-text"
          name={name}
          id={name}
          value={form[name]}
          onChange={handleChange}
          autoComplete={autoComplete}
        />
      </span>
    </p>
  );

  return (
    <PageShell title="Checkout">
      <div className="woocommerce">
        <form name="checkout" className="checkout woocommerce-checkout" onSubmit={handleSubmit}>
          {error && (
            <div className="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout">
              <ul className="woocommerce-error" role="alert">
                <li>{error}</li>
              </ul>
            </div>
          )}
          <div className="col2-set" id="customer_details">
            <div className="col-1">
              <div className="woocommerce-billing-fields">
                <h3>Billing details</h3>
                <div className="woocommerce-billing-fields__field-wrapper">
                  {field("fullName", "Full name", { wide: true, autoComplete: "name" })}
                  {field("address", "Street address", { wide: true, autoComplete: "address-line1" })}
                  {field("city", "Town / City", { wide: true, autoComplete: "address-level2" })}
                  {field("state", "State", { first: true, autoComplete: "address-level1" })}
                  {field("pincode", "PIN Code", { autoComplete: "postal-code" })}
                  {field("phone", "Phone", { type: "tel", wide: true, autoComplete: "tel" })}
                  {field("email", "Email address", { type: "email", wide: true, autoComplete: "email" })}
                </div>
              </div>
            </div>
            <div className="col-2"></div>
          </div>

          <h3 id="order_review_heading">Your order</h3>
          <div id="order_review" className="woocommerce-checkout-review-order">
            <table className="shop_table woocommerce-checkout-review-order-table">
              <thead>
                <tr>
                  <th className="product-name">Product</th>
                  <th className="product-total">Subtotal</th>
                </tr>
              </thead>
              <tbody>
                {items.map(({ key, product, size, price, qty }) => (
                  <tr key={key} className="cart_item">
                    <td className="product-name">
                      {product.name}{size && ` - ${size}`}&nbsp;<strong className="product-quantity">×&nbsp;{qty}</strong>
                    </td>
                    <td className="product-total"><Amount value={price * qty} /></td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="cart-subtotal">
                  <th>Subtotal</th>
                  <td><Amount value={subtotal} /></td>
                </tr>
                <tr className="order-total">
                  <th>Total</th>
                  <td><strong><Amount value={total} /></strong></td>
                </tr>
              </tfoot>
            </table>

            <div id="payment" className="woocommerce-checkout-payment">
              <ul className="wc_payment_methods payment_methods methods">
                {[
                  ["cod", "Cash on delivery", "Pay with cash upon delivery."],
                  ["upi", "UPI", "Pay securely using any UPI app."],
                ].map(([value, label, desc]) => (
                  <li key={value} className={`wc_payment_method payment_method_${value}`}>
                    <input
                      id={`payment_method_${value}`}
                      type="radio"
                      className="input-radio"
                      name="paymentMethod"
                      value={value}
                      checked={form.paymentMethod === value}
                      onChange={handleChange}
                    />
                    <label htmlFor={`payment_method_${value}`}>{label}</label>
                    {form.paymentMethod === value && (
                      <div className={`payment_box payment_method_${value}`}>
                        <p>{desc}</p>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
              <div className="form-row place-order">
                <div className="woocommerce-terms-and-conditions-wrapper">
                  <div className="woocommerce-privacy-policy-text">
                    <p>
                      Your personal data will be used to process your order, support your experience throughout this
                      website, and for other purposes described in our{" "}
                      <a href="/privacy-policy" className="woocommerce-privacy-policy-link">privacy policy</a>.
                    </p>
                  </div>
                </div>
                <button type="submit" className="button alt" name="woocommerce_checkout_place_order" id="place_order" disabled={placing}>
                  {placing
                    ? form.paymentMethod === "upi"
                      ? "Redirecting to UPI..."
                      : "Placing order..."
                    : "Place order"}
                </button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </PageShell>
  );
}
