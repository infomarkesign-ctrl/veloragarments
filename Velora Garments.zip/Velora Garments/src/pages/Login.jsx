import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import PageShell from "../components/PageShell";

export default function Login() {
  const [authMethod, setAuthMethod] = useState("password");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [emailOtp, setEmailOtp] = useState("");
  const [phoneOtp, setPhoneOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [timer, setTimer] = useState(0);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const showMessage = (msg, isError = false) => {
    setError(msg);
    setTimeout(() => setError(""), 3000);
  };

  // Password Login
  const handlePasswordLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      showMessage("Please enter email and password", true);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/auth/verify-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("userEmail", email);
        showMessage("Login successful!");
        setTimeout(() => navigate("/"), 500);
      } else {
        showMessage(data.error || "Invalid credentials", true);
      }
    } catch (error) {
      showMessage("Something went wrong", true);
    } finally {
      setLoading(false);
    }
  };

  // Email OTP
  const handleEmailOtpSend = async (e) => {
    e.preventDefault();
    if (!email) {
      showMessage("Please enter email", true);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/auth/send-email-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();
      if (response.ok) {
        setOtpSent(true);
        showMessage("OTP sent to your email");
        setTimer(60);
        const countdown = setInterval(() => {
          setTimer((prev) => {
            if (prev <= 1) {
              clearInterval(countdown);
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
      } else {
        showMessage(data.error || "Failed to send OTP", true);
      }
    } catch (error) {
      showMessage("Something went wrong", true);
    } finally {
      setLoading(false);
    }
  };

  const handleEmailOtpVerify = async (e) => {
    e.preventDefault();
    if (!emailOtp) {
      showMessage("Please enter OTP", true);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/auth/verify-email-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp: emailOtp }),
      });

      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("userEmail", email);
        showMessage("Login successful!");
        setTimeout(() => navigate("/"), 500);
      } else {
        showMessage(data.error || "Invalid OTP", true);
      }
    } catch (error) {
      showMessage("Something went wrong", true);
    } finally {
      setLoading(false);
    }
  };

  // Phone OTP
  const handlePhoneOtpSend = async (e) => {
    e.preventDefault();
    if (!phoneNumber) {
      showMessage("Please enter phone number", true);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/auth/send-phone-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumber }),
      });

      const data = await response.json();
      if (response.ok) {
        setOtpSent(true);
        showMessage("OTP sent to your phone");
        setTimer(60);
        const countdown = setInterval(() => {
          setTimer((prev) => {
            if (prev <= 1) {
              clearInterval(countdown);
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
      } else {
        showMessage(data.error || "Failed to send OTP", true);
      }
    } catch (error) {
      showMessage("Something went wrong", true);
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneOtpVerify = async (e) => {
    e.preventDefault();
    if (!phoneOtp) {
      showMessage("Please enter OTP", true);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/auth/verify-phone-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phoneNumber, otp: phoneOtp }),
      });

      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("authToken", data.token);
        localStorage.setItem("userPhone", phoneNumber);
        showMessage("Login successful!");
        setTimeout(() => navigate("/"), 500);
      } else {
        showMessage(data.error || "Invalid OTP", true);
      }
    } catch (error) {
      showMessage("Something went wrong", true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <PageShell title="My account">
      <div className="woocommerce">
        <div className="woocommerce-notices-wrapper">
          {error && (
            <div className={`woocommerce-message ${error.includes("successful") ? "" : "woocommerce-error"}`}>
              {error}
            </div>
          )}
        </div>

        <div className="u-columns col2-set" id="customer_login">
          {/* Password Login Tab */}
          {authMethod === "password" && (
            <div className="u-column1 col-1">
              <h2>Login with Password</h2>
              <form className="woocommerce-form woocommerce-form-login login" onSubmit={handlePasswordLogin}>
                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="email">Email address&nbsp;<span className="required">*</span></label>
                  <input
                    type="email"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </p>
                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="password">Password&nbsp;<span className="required">*</span></label>
                  <input
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    type="password"
                    name="password"
                    id="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </p>
                <p className="form-row">
                  <button type="submit" disabled={loading} className="woocommerce-button button woocommerce-form-login__submit">
                    {loading ? "Logging in..." : "Log in"}
                  </button>
                </p>
              </form>
            </div>
          )}

          {/* Email OTP Tab */}
          {authMethod === "emailotp" && (
            <div className="u-column1 col-1">
              <h2>Login with Email OTP</h2>
              <form className="woocommerce-form woocommerce-form-login login" onSubmit={otpSent ? handleEmailOtpVerify : handleEmailOtpSend}>
                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="email_otp">Email address&nbsp;<span className="required">*</span></label>
                  <input
                    type="email"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="email_otp"
                    id="email_otp"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={otpSent}
                    required
                  />
                </p>

                {otpSent && (
                  <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label htmlFor="otp_code">Enter OTP&nbsp;<span className="required">*</span></label>
                    <input
                      type="text"
                      className="woocommerce-Input woocommerce-Input--text input-text"
                      name="otp_code"
                      id="otp_code"
                      placeholder="000000"
                      value={emailOtp}
                      onChange={(e) => setEmailOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                      maxLength={6}
                      required
                    />
                    {timer > 0 && <small className="form-text text-muted">Resend in {timer}s</small>}
                  </p>
                )}

                <p className="form-row">
                  <button type="submit" disabled={loading || (otpSent && emailOtp.length !== 6)} className="woocommerce-button button woocommerce-form-login__submit">
                    {loading ? "Processing..." : otpSent ? "Verify OTP" : "Send OTP"}
                  </button>
                </p>

                {otpSent && (
                  <p className="form-row">
                    <button
                      type="button"
                      className="woocommerce-button button woocommerce-form-login__submit"
                      onClick={() => {
                        setOtpSent(false);
                        setEmailOtp("");
                        setTimer(0);
                      }}
                      disabled={timer > 0}
                    >
                      {timer > 0 ? "Wait..." : "Send New OTP"}
                    </button>
                  </p>
                )}
              </form>
            </div>
          )}

          {/* Phone OTP Tab */}
          {authMethod === "phoneotp" && (
            <div className="u-column1 col-1">
              <h2>Login with Phone OTP</h2>
              <form className="woocommerce-form woocommerce-form-login login" onSubmit={otpSent ? handlePhoneOtpVerify : handlePhoneOtpSend}>
                <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                  <label htmlFor="phone_login">Phone number&nbsp;<span className="required">*</span></label>
                  <input
                    type="tel"
                    className="woocommerce-Input woocommerce-Input--text input-text"
                    name="phone_login"
                    id="phone_login"
                    placeholder="9999999999"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    disabled={otpSent}
                    maxLength={10}
                    required
                  />
                </p>

                {otpSent && (
                  <p className="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label htmlFor="phone_otp_code">Enter OTP&nbsp;<span className="required">*</span></label>
                    <input
                      type="text"
                      className="woocommerce-Input woocommerce-Input--text input-text"
                      name="phone_otp_code"
                      id="phone_otp_code"
                      placeholder="000000"
                      value={phoneOtp}
                      onChange={(e) => setPhoneOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                      maxLength={6}
                      required
                    />
                    {timer > 0 && <small className="form-text text-muted">Resend in {timer}s</small>}
                  </p>
                )}

                <p className="form-row">
                  <button type="submit" disabled={loading || (otpSent && phoneOtp.length !== 6)} className="woocommerce-button button woocommerce-form-login__submit">
                    {loading ? "Processing..." : otpSent ? "Verify OTP" : "Send OTP"}
                  </button>
                </p>

                {otpSent && (
                  <p className="form-row">
                    <button
                      type="button"
                      className="woocommerce-button button woocommerce-form-login__submit"
                      onClick={() => {
                        setOtpSent(false);
                        setPhoneOtp("");
                        setTimer(0);
                      }}
                      disabled={timer > 0}
                    >
                      {timer > 0 ? "Wait..." : "Send New OTP"}
                    </button>
                  </p>
                )}
              </form>
            </div>
          )}

          <div className="u-column2 col-2">
            <h2>Don't have an account?</h2>
            <p>Create an account to get started:</p>
            <Link to="/signup" className="woocommerce-Button woocommerce-button button">
              Create Account
            </Link>
          </div>

          <div style={{ marginTop: "30px", textAlign: "center" }}>
            <h3>Login Method</h3>
            <div style={{ display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
              <button
                onClick={() => setAuthMethod("password")}
                className={`woocommerce-button button ${authMethod === "password" ? "active" : ""}`}
                style={{
                  backgroundColor: authMethod === "password" ? "#333" : "#ddd",
                  color: authMethod === "password" ? "#fff" : "#000",
                }}
              >
                Password
              </button>
              <button
                onClick={() => setAuthMethod("emailotp")}
                className={`woocommerce-button button ${authMethod === "emailotp" ? "active" : ""}`}
                style={{
                  backgroundColor: authMethod === "emailotp" ? "#333" : "#ddd",
                  color: authMethod === "emailotp" ? "#fff" : "#000",
                }}
              >
                Email OTP
              </button>
              <button
                onClick={() => setAuthMethod("phoneotp")}
                className={`woocommerce-button button ${authMethod === "phoneotp" ? "active" : ""}`}
                style={{
                  backgroundColor: authMethod === "phoneotp" ? "#333" : "#ddd",
                  color: authMethod === "phoneotp" ? "#fff" : "#000",
                }}
              >
                Phone OTP
              </button>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}
