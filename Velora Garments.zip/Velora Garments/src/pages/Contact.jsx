import PageShell from "../components/PageShell";
import { site } from "../data/site";

export default function Contact() {
  return (
    <PageShell title="Contact Us">
      <p>
        We’re here to help! Reach out to Velora Garments through any of the channels below and our team will respond
        as soon as possible.
      </p>
      <h2>Customer Support</h2>
      <p>
        Email: <a href={site.mailto}>{site.email}</a>
        <br />
        <strong>Contact No</strong>: <a href={site.tel}>{site.phone}</a>
        <br />
        <strong>Business Hours:</strong> {site.hours}
      </p>
      <h2>Registered Address</h2>
      <p>
        <strong>{site.legalName}</strong>
        <br />
        <br />
        Office No: F-79,
        <br />
        Building Name: Express Zone Mall A Wing, Road: Western Express Highway Nr Patel Vanika. Goregaon East. Mumbai.
        Pin code: 400063
        <br />
        GSTIN: {site.gstin}
      </p>
      <h2>Send Us a Message</h2>
      <p>
        For order enquiries, please include your order number so we can assist you faster. Email us at{" "}
        <a href={site.mailto}>{site.email}</a> and we’ll get back to you within 24 hours.
      </p>
    </PageShell>
  );
}
