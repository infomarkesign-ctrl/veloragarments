import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import About from "./pages/About";
import Shop from "./pages/Shop";
import Contact from "./pages/Contact";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Cart from "./pages/Cart";
import Checkout from "./pages/Checkout";
import OrderConfirmation from "./pages/OrderConfirmation";
import ProductDetails from "./pages/ProductDetails";
import LegalPage from "./pages/LegalPage";

// Astra switches to its mobile header below this width.
const HEADER_BREAKPOINT = 921;

// Body classes WordPress/Astra put on every page; the copied CSS depends on them.
const BASE_BODY =
  "wp-custom-logo wp-embed-responsive wp-theme-astra theme-astra woocommerce-js ast-plain-container ast-no-sidebar astra-4.14.0 ast-inherit-site-logo-transparent ast-hfb-header";

function bodyClassFor(pathname) {
  if (pathname === "/") return "home page ast-single-post";
  if (pathname.startsWith("/shop") || pathname.startsWith("/product-category"))
    return "archive woocommerce woocommerce-page woocommerce-shop columns-4 tablet-columns-3 mobile-columns-2 ast-woo-shop-archive";
  if (pathname.startsWith("/product/"))
    return "single single-product woocommerce woocommerce-page ast-blog-single-style-1 ast-custom-post-type ast-single-post ast-normal-title-enabled";
  const wooPage = {
    "/cart": "woocommerce-cart woocommerce-page",
    "/checkout": "woocommerce-checkout woocommerce-page",
    "/order-confirmation": "woocommerce-checkout woocommerce-page woocommerce-order-received",
    "/my-account": "woocommerce-account woocommerce-page",
  }[pathname];
  return `page ast-single-post ast-normal-title-enabled ${wooPage || ""}`;
}

// Which of public/css/page-*.css the current route needs.
function pageCssFor(pathname) {
  if (pathname === "/") return "home";
  if (pathname.startsWith("/shop") || pathname.startsWith("/product-category")) return "shop";
  if (pathname.startsWith("/product/")) return "product";
  return "page";
}

function useIsMobileHeader() {
  const query = `(max-width: ${HEADER_BREAKPOINT}px)`;
  const [mobile, setMobile] = useState(() => window.matchMedia(query).matches);
  useEffect(() => {
    const mql = window.matchMedia(query);
    const onChange = (e) => setMobile(e.matches);
    mql.addEventListener("change", onChange);
    return () => mql.removeEventListener("change", onChange);
  }, [query]);
  return mobile;
}

function App() {
  const { pathname } = useLocation();
  const mobile = useIsMobileHeader();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    document.body.className = [
      BASE_BODY,
      bodyClassFor(pathname),
      mobile ? "ast-header-break-point" : "ast-desktop",
      mobile && mobileOpen ? "ast-main-header-nav-open" : "",
    ].join(" ");
  }, [pathname, mobile, mobileOpen]);

  useEffect(() => {
    document.getElementById("page-css").setAttribute("href", `/css/page-${pageCssFor(pathname)}.css`);
  }, [pathname]);

  return (
    <div className="hfeed site" id="page">
      <a className="skip-link screen-reader-text" href="#content">Skip to content</a>
      <Navbar mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div id="content" className="site-content">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about-us" element={<About />} />
          <Route path="/shop" element={<Shop />} />
          <Route path="/shop/page/:page" element={<Shop />} />
          <Route path="/product-category/:cat" element={<Shop />} />
          <Route path="/product-category/:cat/page/:page" element={<Shop />} />
          <Route path="/product-category/:cat/:sub" element={<Shop />} />
          <Route path="/product-category/:cat/:sub/page/:page" element={<Shop />} />
          <Route path="/contact-us" element={<Contact />} />
          <Route path="/my-account" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/order-confirmation" element={<OrderConfirmation />} />
          <Route path="/product/:pid" element={<ProductDetails />} />
          <Route path="/privacy-policy" element={<LegalPage page="privacy" />} />
          <Route path="/terms-and-conditions" element={<LegalPage page="terms" />} />
          <Route path="/refund-and-return-policy" element={<LegalPage page="refund" />} />
          <Route path="/shipping-policy" element={<LegalPage page="shipping" />} />
          <Route path="/cancellation-policy" element={<LegalPage page="cancellation" />} />
          {/* Short aliases kept from the previous site */}
          <Route path="/about" element={<Navigate to="/about-us" replace />} />
          <Route path="/contact" element={<Navigate to="/contact-us" replace />} />
          <Route path="/login" element={<Navigate to="/my-account" replace />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
      <Footer />
    </div>
  );
}

export default App;
