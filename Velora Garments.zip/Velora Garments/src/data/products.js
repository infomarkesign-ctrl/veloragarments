// Product data copied from https://veloragarments.store (WooCommerce Store API)
export const categories = [
  { id: "kids", name: "Kids", image: "/img/wp/cat-kids.jpg" },
  { id: "men", name: "Men", image: "/img/wp/cat-men.webp" },
  { id: "women", name: "Women", image: "/img/wp/cat-women.avif" },
];

export const products = [
  {
    "pid": "girls-printed-leggings-set",
    "sku": "VG-K-LG-026",
    "tags": ["kids", "leggings", "set"],
    "cats": [{"name": "Girls", "slug": "girls", "path": "/product-category/kids/girls"}, {"name": "Kids", "slug": "kids", "path": "/product-category/kids"}],
    "thumb": "/img/wp/thumbs/girls-printed-leggings-set.webp",
    "wcId": 64,
    "name": "Girls’ Printed Leggings Set",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "Girls",
    "price": 599,
    "originalPrice": 699,
    "maxPrice": 599,
    "sizes": [],
    "short": "Top-and-leggings set with a cute print — easy, comfy mix-and-match for girls.",
    "descriptionHtml": "<p>A playful coordinated set pairing a printed top with stretchy leggings. Soft, breathable, and easy to wear — a practical everyday favourite for active girls.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Cotton-blend with stretch</li>\n<li>Set: Top + leggings</li>\n<li>Top neck: Round neck</li>\n<li>Leggings waist: Elasticated</li>\n<li>Print: All-over print</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold with like colours. Do not bleach. Do not iron on print. Line dry.</p>",
    "image": "/img/velora/products/girls-printed-leggings-set.webp",
    "images": [
      "/img/velora/products/girls-printed-leggings-set.webp"
    ]
  },
  {
    "pid": "kids-hooded-sweatshirt",
    "sku": "VG-K-SW-025",
    "tags": ["hoodie", "kids", "winter"],
    "cats": [{"name": "Kids", "slug": "kids", "path": "/product-category/kids"}, {"name": "Winter Wear", "slug": "winter-wear-kids", "path": "/product-category/kids/winter-wear-kids"}],
    "thumb": "/img/wp/thumbs/kids-hooded-sweatshirt.webp",
    "wcId": 62,
    "name": "Kids’ Hooded Sweatshirt",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "Winter Wear",
    "price": 629,
    "originalPrice": 799,
    "maxPrice": 729,
    "sizes": [
      {
        "size": "M",
        "price": 629,
        "mrp": 799
      },
      {
        "size": "L",
        "price": 629,
        "mrp": 799
      },
      {
        "size": "XL",
        "price": 729,
        "mrp": 899
      }
    ],
    "short": "Warm fleece hoodie for kids with a kangaroo pocket — cosy winter favourite.",
    "descriptionHtml": "<p>Keep little ones snug with this soft fleece-lined hoodie. An adjustable hood and front pocket add cosy, practical charm for cold days.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Cotton-blend fleece</li>\n<li>Fit: Regular</li>\n<li>Hood: Adjustable</li>\n<li>Pocket: Front kangaroo pocket</li>\n<li>Cuffs &amp; hem: Ribbed</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y, 10-11Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold inside out. Do not iron print. Tumble dry low.</p>",
    "image": "/img/velora/products/kids-hooded-sweatshirt.webp",
    "images": [
      "/img/velora/products/kids-hooded-sweatshirt.webp"
    ]
  },
  {
    "pid": "boys-ethnic-kurta-pyjama-set",
    "sku": "VG-K-KU-024",
    "tags": ["ethnic", "kids", "kurta"],
    "cats": [{"name": "Boys", "slug": "boys", "path": "/product-category/kids/boys"}, {"name": "Kids", "slug": "kids", "path": "/product-category/kids"}],
    "thumb": "/img/wp/thumbs/boys-ethnic-kurta-pyjama-set.webp",
    "wcId": 60,
    "name": "Boys’ Ethnic Kurta Pyjama Set",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "Boys",
    "price": 899,
    "originalPrice": 1099,
    "maxPrice": 999,
    "sizes": [
      {
        "size": "32",
        "price": 899,
        "mrp": 1099
      },
      {
        "size": "34",
        "price": 899,
        "mrp": 1099
      },
      {
        "size": "38",
        "price": 999,
        "mrp": 1099
      }
    ],
    "short": "Festive kurta-pyjama set for boys in soft cotton — celebration-ready ethnic wear.",
    "descriptionHtml": "<p>A handsome kurta-pyjama set that makes festivities special for little ones. Crafted from soft cotton with a comfortable fit for all-day celebration.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% cotton</li>\n<li>Set: Kurta + pyjama</li>\n<li>Collar: Mandarin collar</li>\n<li>Sleeves: Full sleeves</li>\n<li>Closure: Button placket</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y, 10-11Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Gentle machine wash cold. Wash separately. Medium iron. Dry in shade.</p>",
    "image": "/img/velora/products/boys-ethnic-kurta-pyjama-set.webp",
    "images": [
      "/img/velora/products/boys-ethnic-kurta-pyjama-set.webp"
    ]
  },
  {
    "pid": "kids-jogger-pants",
    "sku": "VG-K-JG-023",
    "tags": ["casual", "joggers", "kids"],
    "cats": [{"name": "Bottomwear", "slug": "bottomwear-kids", "path": "/product-category/kids/bottomwear-kids"}, {"name": "Kids", "slug": "kids", "path": "/product-category/kids"}],
    "thumb": "/img/wp/thumbs/kids-jogger-pants.webp",
    "wcId": 58,
    "name": "Kids’ Jogger Pants",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "Bottomwear",
    "price": 379,
    "originalPrice": 499,
    "maxPrice": 479,
    "sizes": [
      {
        "size": "32",
        "price": 379,
        "mrp": 499
      },
      {
        "size": "34",
        "price": 379,
        "mrp": 499
      },
      {
        "size": "36",
        "price": 479,
        "mrp": 599
      },
      {
        "size": "38",
        "price": 479,
        "mrp": 599
      }
    ],
    "short": "Stretchy jogger pants with an elastic waist — comfy, active everyday wear.",
    "descriptionHtml": "<p>Comfy joggers built for play, with a soft stretch fabric and elasticated drawstring waist. Ribbed ankle cuffs keep them neat while kids stay on the move.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Cotton-blend fleece</li>\n<li>Fit: Regular jogger</li>\n<li>Waist: Elasticated drawstring</li>\n<li>Pockets: Two side pockets</li>\n<li>Hem: Ribbed ankle</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y, 10-11Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold. Do not bleach. Tumble dry low. Warm iron if needed.</p>",
    "image": "/img/velora/products/kids-jogger-pants.webp",
    "images": [
      "/img/velora/products/kids-jogger-pants.webp"
    ]
  },
  {
    "pid": "girls-party-dress",
    "sku": "VG-K-DR-022",
    "tags": ["dress", "kids", "party"],
    "cats": [{"name": "Girls", "slug": "girls", "path": "/product-category/kids/girls"}, {"name": "Kids", "slug": "kids", "path": "/product-category/kids"}],
    "thumb": "/img/wp/thumbs/girls-party-dress.webp",
    "wcId": 56,
    "name": "Girls’ Party Dress",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "Girls",
    "price": 799,
    "originalPrice": 899,
    "maxPrice": 899,
    "sizes": [
      {
        "size": "M",
        "price": 799,
        "mrp": 899
      },
      {
        "size": "L",
        "price": 799,
        "mrp": 899
      },
      {
        "size": "XL",
        "price": 899,
        "mrp": 999
      }
    ],
    "short": "Pretty party dress with a flared skirt — made for birthdays and special days.",
    "descriptionHtml": "<p>A charming party dress with a twirl-worthy flared skirt and delicate detailing. Soft lining keeps it comfortable so she can celebrate all day.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Polyester with soft inner lining</li>\n<li>Fit: Fit-and-flare</li>\n<li>Neck: Round neck</li>\n<li>Sleeves: Short / cap sleeves</li>\n<li>Closure: Back zip</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Gentle hand wash cold. Do not bleach. Cool iron. Dry flat in shade.</p>",
    "image": "/img/velora/products/girls-party-dress.webp",
    "images": [
      "/img/velora/products/girls-party-dress.webp"
    ]
  },
  {
    "pid": "boys-casual-shirt",
    "sku": "VG-K-SH-021",
    "tags": ["casual", "kids", "shirt"],
    "cats": [{"name": "Boys", "slug": "boys", "path": "/product-category/kids/boys"}, {"name": "Kids", "slug": "kids", "path": "/product-category/kids"}],
    "thumb": "/img/wp/thumbs/boys-casual-shirt.webp",
    "wcId": 54,
    "name": "Boys’ Casual Shirt",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "Boys",
    "price": 429,
    "originalPrice": 549,
    "maxPrice": 529,
    "sizes": [
      {
        "size": "M",
        "price": 429,
        "mrp": 549
      },
      {
        "size": "L",
        "price": 429,
        "mrp": 549
      },
      {
        "size": "XL",
        "price": 529,
        "mrp": 649
      }
    ],
    "short": "Smart-casual cotton shirt for boys — great for parties and family days out.",
    "descriptionHtml": "<p>A dapper casual shirt for boys in soft, breathable cotton. Smart enough for celebrations and comfy enough for everyday wear.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% cotton</li>\n<li>Fit: Regular</li>\n<li>Collar: Spread collar</li>\n<li>Sleeves: Full sleeves</li>\n<li>Closure: Button front</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y, 10-11Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold. Do not bleach. Warm iron. Line dry in shade.</p>",
    "image": "/img/velora/products/boys-casual-shirt.webp",
    "images": [
      "/img/velora/products/boys-casual-shirt.webp"
    ]
  },
  {
    "pid": "kids-cotton-frock",
    "sku": "VG-K-FR-020",
    "tags": ["cotton", "frock", "kids"],
    "cats": [{"name": "Girls", "slug": "girls", "path": "/product-category/kids/girls"}, {"name": "Kids", "slug": "kids", "path": "/product-category/kids"}],
    "thumb": "/img/wp/thumbs/kids-cotton-frock.jpg",
    "wcId": 52,
    "name": "Kids’ Cotton Frock",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "Girls",
    "price": 549,
    "originalPrice": 699,
    "maxPrice": 649,
    "sizes": [
      {
        "size": "M",
        "price": 549,
        "mrp": 699
      },
      {
        "size": "L",
        "price": 549,
        "mrp": 699
      },
      {
        "size": "XL",
        "price": 649,
        "mrp": 799
      }
    ],
    "short": "Adorable cotton frock with a comfy fit — perfect for playdates and outings.",
    "descriptionHtml": "<p>A sweet everyday frock in soft, breathable cotton that lets little ones move and play freely. Easy to wear and even easier to love.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% cotton</li>\n<li>Fit: A-line frock</li>\n<li>Neck: Round neck</li>\n<li>Sleeves: Short sleeves</li>\n<li>Closure: Back button</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold with like colours. Do not bleach. Warm iron. Line dry in shade.</p>",
    "image": "/img/velora/products/kids-cotton-frock.jpg",
    "images": [
      "/img/velora/products/kids-cotton-frock.jpg"
    ]
  },
  {
    "pid": "kids-cartoon-print-t-shirt",
    "sku": "VG-K-TS-019",
    "tags": ["casual", "cotton", "kids"],
    "cats": [{"name": "Kids", "slug": "kids", "path": "/product-category/kids"}, {"name": "T-Shirts", "slug": "t-shirts-kids", "path": "/product-category/kids/t-shirts-kids"}],
    "thumb": "/img/wp/thumbs/kids-cartoon-print-t-shirt.webp",
    "wcId": 50,
    "name": "Kids’ Cartoon Print T-Shirt",
    "categoryId": "kids",
    "category": "Kids",
    "subCategory": "T-Shirts",
    "price": 299,
    "originalPrice": 399,
    "maxPrice": 399,
    "sizes": [
      {
        "size": "M",
        "price": 299,
        "mrp": 399
      },
      {
        "size": "L",
        "price": 299,
        "mrp": 399
      },
      {
        "size": "XL",
        "price": 399,
        "mrp": 499
      },
      {
        "size": "XXL",
        "price": 399,
        "mrp": 499
      }
    ],
    "short": "Fun cartoon-print tee in soft cotton — comfy play-all-day wear for kids.",
    "descriptionHtml": "<p>A cheerful cotton T-shirt with a playful cartoon print kids love. The soft, skin-friendly fabric keeps little ones comfortable through every adventure.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% soft cotton</li>\n<li>Fit: Regular</li>\n<li>Neck: Round neck</li>\n<li>Sleeves: Short sleeves</li>\n<li>Print: Cartoon graphic</li>\n<li>Sizes: 2-3Y, 4-5Y, 6-7Y, 8-9Y, 10-11Y</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold inside out. Do not bleach. Do not iron on print. Line dry.</p>",
    "image": "/img/velora/products/kids-cartoon-print-t-shirt.webp",
    "images": [
      "/img/velora/products/kids-cartoon-print-t-shirt.webp"
    ]
  },
  {
    "pid": "womens-denim-jacket",
    "sku": "VG-W-JK-018",
    "tags": ["casual", "denim", "jacket"],
    "cats": [{"name": "Winter Wear", "slug": "winter-wear-women", "path": "/product-category/women/winter-wear-women"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-denim-jacket.webp",
    "wcId": 48,
    "name": "Women’s Denim Jacket",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Winter Wear",
    "price": 1299,
    "originalPrice": 1599,
    "maxPrice": 1399,
    "sizes": [
      {
        "size": "M",
        "price": 1299,
        "mrp": 1599
      },
      {
        "size": "L",
        "price": 1299,
        "mrp": 1599
      },
      {
        "size": "XL",
        "price": 1399,
        "mrp": 1699
      }
    ],
    "short": "Classic denim jacket with a cropped fit — the layer that goes with everything.",
    "descriptionHtml": "<p>A timeless denim jacket in a flattering cropped length. Sturdy yet comfortable, it layers effortlessly over dresses, kurtis, and tees for an instant style boost.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% cotton denim</li>\n<li>Fit: Cropped regular</li>\n<li>Closure: Button front</li>\n<li>Pockets: Two chest + two side</li>\n<li>Collar: Classic denim collar</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold inside out. Wash separately. Do not bleach. Line dry in shade.</p>",
    "image": "/img/velora/products/womens-denim-jacket.webp",
    "images": [
      "/img/velora/products/womens-denim-jacket.webp"
    ]
  },
  {
    "pid": "womens-embroidered-palazzo-set",
    "sku": "VG-W-PL-017",
    "tags": ["ethnic", "palazzo", "set"],
    "cats": [{"name": "Ethnic Wear", "slug": "ethnic-wear-women", "path": "/product-category/women/ethnic-wear-women"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-embroidered-palazzo-set.webp",
    "wcId": 46,
    "name": "Women’s Embroidered Palazzo Set",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Ethnic Wear",
    "price": 1449,
    "originalPrice": 1799,
    "maxPrice": 1549,
    "sizes": [
      {
        "size": "M",
        "price": 1449,
        "mrp": 1799
      },
      {
        "size": "L",
        "price": 1449,
        "mrp": 1799
      },
      {
        "size": "XL",
        "price": 1549,
        "mrp": 1899
      }
    ],
    "short": "Coordinated kurti and palazzo set with delicate embroidery — festive-ready ethnic wear.",
    "descriptionHtml": "<p>A graceful coordinated set pairing an embroidered straight kurti with flowing palazzo pants. Lightweight and breathable, it is made for long days of celebration in comfort.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Rayon with embroidery</li>\n<li>Set: Kurti + palazzo</li>\n<li>Work: Embroidered yoke</li>\n<li>Kurti length: Knee length</li>\n<li>Sleeves: 3/4 sleeves</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Gentle hand wash cold. Wash separately. Medium iron on reverse. Dry in shade.</p>",
    "image": "/img/velora/products/womens-embroidered-palazzo-set.webp",
    "images": [
      "/img/velora/products/womens-embroidered-palazzo-set.webp"
    ]
  },
  {
    "pid": "womens-cotton-leggings-pack-of-2",
    "sku": "VG-W-LG-016",
    "tags": ["basics", "cotton", "leggings"],
    "cats": [{"name": "Bottomwear", "slug": "bottomwear", "path": "/product-category/women/bottomwear"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-cotton-leggings-pack-of-2.webp",
    "wcId": 44,
    "name": "Women’s Cotton Leggings (Pack of 2)",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Bottomwear",
    "price": 549,
    "originalPrice": 699,
    "maxPrice": 649,
    "sizes": [
      {
        "size": "M",
        "price": 549,
        "mrp": 699
      },
      {
        "size": "L",
        "price": 549,
        "mrp": 699
      },
      {
        "size": "XL",
        "price": 649,
        "mrp": 799
      }
    ],
    "short": "Pack of 2 stretch cotton leggings with a wide comfort waistband — pairs with everything.",
    "descriptionHtml": "<p>Everyday essential leggings in a value pack of two, made from 4-way stretch cotton-Lycra that moves with you. A wide elasticated waistband stays put all day.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Cotton-Lycra 4-way stretch</li>\n<li>Pack: 2 leggings</li>\n<li>Waist: Wide elasticated waistband</li>\n<li>Length: Ankle length</li>\n<li>Fit: Skinny</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold. Do not bleach. Do not iron directly. Line dry in shade.</p>",
    "image": "/img/velora/products/womens-cotton-leggings-pack-of-2.webp",
    "images": [
      "/img/velora/products/womens-cotton-leggings-pack-of-2.webp"
    ]
  },
  {
    "pid": "womens-a-line-midi-dress",
    "sku": "VG-W-DR-015",
    "tags": ["casual", "dress", "midi"],
    "cats": [{"name": "Dresses", "slug": "dresses", "path": "/product-category/women/dresses"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-a-line-midi-dress.avif",
    "wcId": 42,
    "name": "Women’s A-Line Midi Dress",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Dresses",
    "price": 999,
    "originalPrice": 1299,
    "maxPrice": 1250,
    "sizes": [
      {
        "size": "M",
        "price": 999,
        "mrp": 1299
      },
      {
        "size": "L",
        "price": 999,
        "mrp": 1299
      },
      {
        "size": "XL",
        "price": 1250,
        "mrp": 1399
      }
    ],
    "short": "Flattering A-line midi dress for work or weekend — comfortable and chic.",
    "descriptionHtml": "<p>A graceful A-line midi dress that skims the figure for a flattering silhouette. Made from soft, breathable fabric, it transitions easily from desk to dinner.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Polyester-blend crepe</li>\n<li>Fit: A-line</li>\n<li>Length: Midi</li>\n<li>Neck: Round neck</li>\n<li>Sleeves: Short sleeves</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Gentle machine wash cold. Do not bleach. Cool iron. Line dry in shade.</p>",
    "image": "/img/velora/products/womens-a-line-midi-dress.avif",
    "images": [
      "/img/velora/products/womens-a-line-midi-dress.avif"
    ]
  },
  {
    "pid": "womens-georgette-printed-saree",
    "sku": "VG-W-SR-014",
    "tags": ["ethnic", "georgette", "saree"],
    "cats": [{"name": "Sarees", "slug": "sarees", "path": "/product-category/women/sarees"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-georgette-printed-saree.jpg",
    "wcId": 40,
    "name": "Women’s Georgette Printed Saree",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Sarees",
    "price": 1999,
    "originalPrice": 2499,
    "maxPrice": 1999,
    "sizes": [],
    "short": "Lightweight georgette saree with a graceful printed drape and matching blouse piece.",
    "descriptionHtml": "<p>A beautifully fluid georgette saree that drapes with elegance and ease. The all-over print and soft fall make it a go-to for parties, festivities, and special occasions. Comes with an unstitched matching blouse piece.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Georgette</li>\n<li>Length: 5.5 m saree + 0.8 m blouse piece</li>\n<li>Work: All-over print</li>\n<li>Blouse: Unstitched</li>\n<li>Occasion: Party / festive</li>\n<li>Care: Dry clean recommended</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Dry clean only for best results. Iron on low heat. Store folded in a muslin cloth.</p>",
    "image": "/img/velora/products/womens-georgette-printed-saree.jpg",
    "images": [
      "/img/velora/products/womens-georgette-printed-saree.jpg"
    ]
  },
  {
    "pid": "womens-casual-round-neck-top",
    "sku": "VG-W-TP-013",
    "tags": ["basics", "casual", "top"],
    "cats": [{"name": "Tops", "slug": "tops", "path": "/product-category/women/tops"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-casual-round-neck-top.avif",
    "wcId": 38,
    "name": "Women’s Casual Round Neck Top",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Tops",
    "price": 449,
    "originalPrice": 599,
    "maxPrice": 549,
    "sizes": [
      {
        "size": "M",
        "price": 449,
        "mrp": 599
      },
      {
        "size": "L",
        "price": 449,
        "mrp": 599
      },
      {
        "size": "XL",
        "price": 549,
        "mrp": 699
      }
    ],
    "short": "Soft round-neck top in a relaxed fit — an effortless everyday layer.",
    "descriptionHtml": "<p>A wardrobe staple round-neck top in soft, breathable knit. Its relaxed fit and clean lines make it perfect on its own or layered under jackets and shrugs.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Cotton-blend knit</li>\n<li>Fit: Regular / relaxed</li>\n<li>Neck: Round neck</li>\n<li>Sleeves: Short sleeves</li>\n<li>Pattern: Solid</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold with like colours. Do not bleach. Warm iron. Line dry.</p>",
    "image": "/img/velora/products/womens-casual-round-neck-top.avif",
    "images": [
      "/img/velora/products/womens-casual-round-neck-top.avif"
    ]
  },
  {
    "pid": "womens-skinny-fit-jeans",
    "sku": "VG-W-JN-012",
    "tags": ["casual", "denim", "skinny"],
    "cats": [{"name": "Jeans", "slug": "jeans-women", "path": "/product-category/women/jeans-women"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-skinny-fit-jeans.avif",
    "wcId": 36,
    "name": "Women’s Skinny Fit Jeans",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Jeans",
    "price": 949,
    "originalPrice": 1199,
    "maxPrice": 1150,
    "sizes": [
      {
        "size": "M",
        "price": 949,
        "mrp": 1199
      },
      {
        "size": "L",
        "price": 949,
        "mrp": 1199
      },
      {
        "size": "XL",
        "price": 1150,
        "mrp": 1299
      }
    ],
    "short": "High-rise skinny jeans with all-day stretch — a flattering everyday fit.",
    "descriptionHtml": "<p>Sculpting high-rise skinny jeans crafted from premium stretch denim that hugs your shape and holds it. Clean five-pocket styling makes them endlessly versatile.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 92% cotton, 6% polyester, 2% elastane</li>\n<li>Fit: Skinny</li>\n<li>Rise: High-rise</li>\n<li>Closure: Button &amp; zip fly</li>\n<li>Pockets: 5-pocket styling</li>\n<li>Sizes: 26, 28, 30, 32, 34</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash inside out cold. Wash separately. Do not bleach. Line dry in shade.</p>",
    "image": "/img/velora/products/womens-skinny-fit-jeans.avif",
    "images": [
      "/img/velora/products/womens-skinny-fit-jeans.avif"
    ]
  },
  {
    "pid": "womens-cotton-anarkali-kurta",
    "sku": "VG-W-KU-011",
    "tags": ["anarkali", "cotton", "ethnic"],
    "cats": [{"name": "Ethnic Wear", "slug": "ethnic-wear-women", "path": "/product-category/women/ethnic-wear-women"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-cotton-anarkali-kurta.webp",
    "wcId": 34,
    "name": "Women’s Cotton Anarkali Kurta",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Ethnic Wear",
    "price": 1199,
    "originalPrice": 1499,
    "maxPrice": 1299,
    "sizes": [
      {
        "size": "M",
        "price": 1199,
        "mrp": 1499
      },
      {
        "size": "L",
        "price": 1199,
        "mrp": 1499
      },
      {
        "size": "XL",
        "price": 1299,
        "mrp": 1599
      }
    ],
    "short": "Elegant flared Anarkali kurta in pure cotton — festive elegance, all-day comfort.",
    "descriptionHtml": "<p>A gracefully flared Anarkali kurta in breathable cotton, designed to flatter every figure. Subtle detailing makes it equally at home at festivities and family gatherings.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% cotton</li>\n<li>Fit: Flared / Anarkali</li>\n<li>Length: Calf length</li>\n<li>Neck: Round neck with detailing</li>\n<li>Sleeves: 3/4 sleeves</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Gentle machine wash cold. Wash dark shades separately. Medium iron. Dry in shade.</p>",
    "image": "/img/velora/products/womens-cotton-anarkali-kurta.webp",
    "images": [
      "/img/velora/products/womens-cotton-anarkali-kurta.webp"
    ]
  },
  {
    "pid": "womens-floral-print-kurti",
    "sku": "VG-W-KU-010",
    "tags": ["ethnic", "floral", "kurti"],
    "cats": [{"name": "Kurtis", "slug": "kurtis", "path": "/product-category/women/kurtis"}, {"name": "Women", "slug": "women", "path": "/product-category/women"}],
    "thumb": "/img/wp/thumbs/womens-floral-print-kurti.jpg",
    "wcId": 32,
    "name": "Women’s Floral Print Kurti",
    "categoryId": "women",
    "category": "Women",
    "subCategory": "Kurtis",
    "price": 699,
    "originalPrice": 799,
    "maxPrice": 799,
    "sizes": [
      {
        "size": "M",
        "price": 699,
        "mrp": 799
      },
      {
        "size": "L",
        "price": 699,
        "mrp": 799
      },
      {
        "size": "XL",
        "price": 799,
        "mrp": 899
      }
    ],
    "short": "Flowy floral-print kurti in soft rayon — graceful everyday ethnic wear.",
    "descriptionHtml": "<p>A breezy straight kurti in a charming floral print, cut from soft rayon that drapes beautifully. Lightweight and comfortable for work, college, or casual outings.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Soft rayon</li>\n<li>Fit: Straight</li>\n<li>Length: Knee length</li>\n<li>Neck: Round neck</li>\n<li>Sleeves: 3/4 sleeves</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Hand wash or gentle machine wash cold. Wash separately. Medium iron. Dry in shade.</p>",
    "image": "/img/velora/products/womens-floral-print-kurti.jpg",
    "images": [
      "/img/velora/products/womens-floral-print-kurti.jpg"
    ]
  },
  {
    "pid": "mens-slim-fit-track-pants",
    "sku": "VG-M-TP-009",
    "tags": ["casual", "sports", "track pants"],
    "cats": [{"name": "Activewear", "slug": "activewear", "path": "/product-category/men/activewear"}, {"name": "Men", "slug": "men", "path": "/product-category/men"}],
    "thumb": "/img/wp/thumbs/mens-slim-fit-track-pants.webp",
    "wcId": 30,
    "name": "Men’s Slim Fit Track Pants",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "Activewear",
    "price": 599,
    "originalPrice": 749,
    "maxPrice": 699,
    "sizes": [
      {
        "size": "32",
        "price": 599,
        "mrp": 749
      },
      {
        "size": "34",
        "price": 599,
        "mrp": 749
      },
      {
        "size": "36",
        "price": 699,
        "mrp": 849
      }
    ],
    "short": "Slim-fit track pants with stretch and zip pockets — gym to street ready.",
    "descriptionHtml": "<p>Move freely in these slim-fit track pants made from quick-dry stretch fabric. Secure zip pockets and an elasticated drawstring waist keep things practical and comfortable.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Polyester-cotton stretch blend</li>\n<li>Fit: Slim</li>\n<li>Waist: Elasticated with drawstring</li>\n<li>Pockets: Two zip side pockets</li>\n<li>Hem: Ribbed ankle</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold. Do not iron directly on prints. Tumble dry low.</p>",
    "image": "/img/velora/products/mens-slim-fit-track-pants.webp",
    "images": [
      "/img/velora/products/mens-slim-fit-track-pants.webp"
    ]
  },
  {
    "pid": "mens-bomber-jacket",
    "sku": "VG-M-JK-008",
    "tags": ["bomber", "jacket", "winter"],
    "cats": [{"name": "Men", "slug": "men", "path": "/product-category/men"}, {"name": "Winter Wear", "slug": "winter-wear", "path": "/product-category/men/winter-wear"}],
    "thumb": "/img/wp/thumbs/mens-bomber-jacket.webp",
    "wcId": 28,
    "name": "Men’s Bomber Jacket",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "Winter Wear",
    "price": 1599,
    "originalPrice": 1999,
    "maxPrice": 1699,
    "sizes": [
      {
        "size": "M",
        "price": 1599,
        "mrp": 1999
      },
      {
        "size": "L",
        "price": 1599,
        "mrp": 1999
      },
      {
        "size": "XL",
        "price": 1699,
        "mrp": 1999
      }
    ],
    "short": "Lightweight bomber jacket with ribbed trims — a year-round layering staple.",
    "descriptionHtml": "<p>A versatile bomber jacket with a smooth shell and soft inner lining, finished with ribbed collar, cuffs, and hem for a snug fit. Perfect for layering across seasons.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Polyester shell with soft lining</li>\n<li>Fit: Regular</li>\n<li>Closure: Full-zip front</li>\n<li>Pockets: Two side pockets</li>\n<li>Trims: Ribbed collar, cuffs &amp; hem</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold gentle cycle. Do not bleach. Do not tumble dry. Cool iron if needed.</p>",
    "image": "/img/velora/products/mens-bomber-jacket.webp",
    "images": [
      "/img/velora/products/mens-bomber-jacket.webp"
    ]
  },
  {
    "pid": "mens-polo-collar-t-shirt",
    "sku": "VG-M-PL-007",
    "tags": ["casual", "cotton", "polo"],
    "cats": [{"name": "Men", "slug": "men", "path": "/product-category/men"}, {"name": "T-Shirts", "slug": "t-shirts", "path": "/product-category/men/t-shirts"}],
    "thumb": "/img/wp/thumbs/mens-polo-collar-t-shirt.jpg",
    "wcId": 26,
    "name": "Men’s Polo Collar T-Shirt",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "T-Shirts",
    "price": 649,
    "originalPrice": 649,
    "maxPrice": 700,
    "sizes": [
      {
        "size": "M",
        "price": 649,
        "mrp": 649
      },
      {
        "size": "L",
        "price": 649,
        "mrp": 649
      },
      {
        "size": "XL",
        "price": 700,
        "mrp": 700
      }
    ],
    "short": "Breathable pique-knit polo with a ribbed collar — smart-casual essential.",
    "descriptionHtml": "<p>A classic polo in soft pique-knit cotton that keeps you cool and looking sharp. The ribbed collar and two-button placket bring an instant smart-casual upgrade.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% pique-knit cotton</li>\n<li>Fit: Regular</li>\n<li>Collar: Ribbed polo collar</li>\n<li>Placket: Two-button</li>\n<li>Sleeves: Short sleeves with ribbed cuffs</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold with similar colours. Do not bleach. Warm iron. Line dry.</p>",
    "image": "/img/velora/products/mens-polo-collar-t-shirt.jpg",
    "images": [
      "/img/velora/products/mens-polo-collar-t-shirt.jpg"
    ]
  },
  {
    "pid": "mens-cotton-straight-kurta",
    "sku": "VG-M-KU-006",
    "tags": ["cotton", "ethnic", "kurta"],
    "cats": [{"name": "Ethnic Wear", "slug": "ethnic-wear", "path": "/product-category/men/ethnic-wear"}, {"name": "Men", "slug": "men", "path": "/product-category/men"}],
    "thumb": "/img/wp/thumbs/mens-cotton-straight-kurta.webp",
    "wcId": 24,
    "name": "Men’s Cotton Straight Kurta",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "Ethnic Wear",
    "price": 950,
    "originalPrice": 1099,
    "maxPrice": 1050,
    "sizes": [
      {
        "size": "32",
        "price": 950,
        "mrp": 1099
      },
      {
        "size": "34",
        "price": 950,
        "mrp": 1099
      },
      {
        "size": "36",
        "price": 1050,
        "mrp": 1200
      }
    ],
    "short": "Handsome straight-cut cotton kurta for festive and everyday ethnic wear.",
    "descriptionHtml": "<p>A versatile straight-cut kurta crafted from breathable pure cotton, ideal for festivals, pujas, and casual ethnic days. Subtle detailing at the placket adds an elegant finish.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% pure cotton</li>\n<li>Fit: Straight</li>\n<li>Length: Knee length</li>\n<li>Collar: Mandarin collar</li>\n<li>Sleeves: Full sleeves</li>\n<li>Sizes: 38, 40, 42, 44, 46</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Gentle machine wash cold. Wash dark colours separately. Medium iron. Dry in shade.</p>",
    "image": "/img/velora/products/mens-cotton-straight-kurta.webp",
    "images": [
      "/img/velora/products/mens-cotton-straight-kurta.webp"
    ]
  },
  {
    "pid": "mens-hooded-sweatshirt",
    "sku": "VG-M-SW-005",
    "tags": ["fleece", "hoodie", "winter"],
    "cats": [{"name": "Men", "slug": "men", "path": "/product-category/men"}, {"name": "Winter Wear", "slug": "winter-wear", "path": "/product-category/men/winter-wear"}],
    "thumb": "/img/wp/thumbs/mens-hooded-sweatshirt.jpg",
    "wcId": 22,
    "name": "Men’s Hooded Sweatshirt",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "Winter Wear",
    "price": 899,
    "originalPrice": 1199,
    "maxPrice": 999,
    "sizes": [
      {
        "size": "M",
        "price": 899,
        "mrp": 1199
      },
      {
        "size": "L",
        "price": 899,
        "mrp": 1199
      },
      {
        "size": "XL",
        "price": 999,
        "mrp": 1299
      }
    ],
    "short": "Cosy fleece-lined hooded sweatshirt with a kangaroo pocket — warm and casual.",
    "descriptionHtml": "<p>Stay warm in this soft fleece-lined hoodie built for chilly days. Features an adjustable drawstring hood, ribbed cuffs and hem, and a handy kangaroo pocket.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: Cotton-blend fleece, 320 GSM</li>\n<li>Fit: Regular</li>\n<li>Hood: Adjustable drawstring</li>\n<li>Pocket: Front kangaroo pocket</li>\n<li>Cuffs &amp; hem: Ribbed</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold inside out. Do not iron print. Tumble dry low.</p>",
    "image": "/img/velora/products/mens-hooded-sweatshirt.jpg",
    "images": [
      "/img/velora/products/mens-hooded-sweatshirt.jpg"
    ]
  },
  {
    "pid": "mens-casual-checked-shirt",
    "sku": "VG-M-SH-004",
    "tags": ["casual", "checked", "cotton"],
    "cats": [{"name": "Men", "slug": "men", "path": "/product-category/men"}, {"name": "Shirts", "slug": "shirts", "path": "/product-category/men/shirts"}],
    "thumb": "/img/wp/thumbs/mens-casual-checked-shirt.webp",
    "wcId": 20,
    "name": "Men’s Casual Checked Shirt",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "Shirts",
    "price": 649,
    "originalPrice": 799,
    "maxPrice": 749,
    "sizes": [
      {
        "size": "M",
        "price": 649,
        "mrp": 799
      },
      {
        "size": "L",
        "price": 649,
        "mrp": 799
      },
      {
        "size": "XL",
        "price": 749,
        "mrp": 899
      }
    ],
    "short": "Soft cotton casual shirt in a classic check — easy, versatile weekend wear.",
    "descriptionHtml": "<p>A relaxed casual shirt in a timeless check pattern, woven from soft yarn-dyed cotton. Pairs effortlessly with jeans or chinos for an easygoing, put-together look.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% yarn-dyed cotton</li>\n<li>Fit: Regular</li>\n<li>Collar: Button-down collar</li>\n<li>Pattern: Checked</li>\n<li>Sleeves: Full sleeves with roll-up tabs</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold with like colours. Do not bleach. Warm iron. Line dry in shade.</p>",
    "image": "/img/velora/products/mens-casual-checked-shirt.webp",
    "images": [
      "/img/velora/products/mens-casual-checked-shirt.webp"
    ]
  },
  {
    "pid": "mens-formal-cotton-shirt",
    "sku": "VG-M-SH-003",
    "tags": ["cotton", "formal", "office"],
    "cats": [{"name": "Men", "slug": "men", "path": "/product-category/men"}, {"name": "Shirts", "slug": "shirts", "path": "/product-category/men/shirts"}],
    "thumb": "/img/wp/thumbs/mens-formal-cotton-shirt.webp",
    "wcId": 18,
    "name": "Men’s Formal Cotton Shirt",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "Shirts",
    "price": 899,
    "originalPrice": 899,
    "maxPrice": 999,
    "sizes": [
      {
        "size": "M",
        "price": 899,
        "mrp": 899
      },
      {
        "size": "L",
        "price": 899,
        "mrp": 899
      },
      {
        "size": "XL",
        "price": 999,
        "mrp": 999
      }
    ],
    "short": "Wrinkle-resistant formal cotton shirt with a smart spread collar — boardroom ready.",
    "descriptionHtml": "<p>A crisp formal shirt tailored from fine wrinkle-resistant cotton. The structured spread collar and clean lines deliver a polished look for office and occasion wear alike.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% premium cotton</li>\n<li>Fit: Regular</li>\n<li>Collar: Spread collar</li>\n<li>Cuffs: Single-button barrel cuffs</li>\n<li>Pattern: Solid</li>\n<li>Sizes: 38, 40, 42, 44, 46</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold or dry clean. Iron on medium heat. Do not bleach.</p>",
    "image": "/img/velora/products/mens-formal-cotton-shirt.webp",
    "images": [
      "/img/velora/products/mens-formal-cotton-shirt.webp"
    ]
  },
  {
    "pid": "mens-slim-fit-stretch-denim-jeans",
    "sku": "VG-M-JN-002",
    "tags": ["casual", "denim", "slim fit"],
    "cats": [{"name": "Jeans", "slug": "jeans", "path": "/product-category/men/jeans"}, {"name": "Men", "slug": "men", "path": "/product-category/men"}],
    "thumb": "/img/wp/thumbs/mens-slim-fit-stretch-denim-jeans.webp",
    "wcId": 16,
    "name": "Men’s Slim Fit Stretch Denim Jeans",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "Jeans",
    "price": 999,
    "originalPrice": 1299,
    "maxPrice": 1150,
    "sizes": [
      {
        "size": "32",
        "price": 999,
        "mrp": 1299
      },
      {
        "size": "34",
        "price": 999,
        "mrp": 1299
      },
      {
        "size": "36",
        "price": 1150,
        "mrp": 1399
      }
    ],
    "short": "Slim-fit stretchable denim with a mid-rise waist — comfortable enough for all-day wear.",
    "descriptionHtml": "<p>Engineered from premium stretch denim, these slim-fit jeans move with you while keeping a sharp silhouette. A mid-rise waist and clean five-pocket styling make them easy to dress up or down.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 98% cotton, 2% elastane stretch denim</li>\n<li>Fit: Slim</li>\n<li>Rise: Mid-rise</li>\n<li>Closure: Button &amp; zip fly</li>\n<li>Pockets: 5-pocket styling</li>\n<li>Sizes: 28, 30, 32, 34, 36, 38</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash inside out with cold water. Wash separately. Do not bleach. Line dry in shade.</p>",
    "image": "/img/velora/products/mens-slim-fit-stretch-denim-jeans.webp",
    "images": [
      "/img/velora/products/mens-slim-fit-stretch-denim-jeans.webp"
    ]
  },
  {
    "pid": "mens-classic-cotton-crew-neck-t-shirt",
    "sku": "VG-M-TS-001",
    "tags": ["basics", "casual", "cotton"],
    "cats": [{"name": "Men", "slug": "men", "path": "/product-category/men"}, {"name": "T-Shirts", "slug": "t-shirts", "path": "/product-category/men/t-shirts"}],
    "thumb": "/img/wp/thumbs/mens-classic-cotton-crew-neck-t-shirt.jpg",
    "wcId": 14,
    "name": "Men’s Classic Cotton Crew Neck T-Shirt",
    "categoryId": "men",
    "category": "Men",
    "subCategory": "T-Shirts",
    "price": 399,
    "originalPrice": 499,
    "maxPrice": 499,
    "sizes": [
      {
        "size": "M",
        "price": 399,
        "mrp": 499
      },
      {
        "size": "L",
        "price": 399,
        "mrp": 499
      },
      {
        "size": "XL",
        "price": 499,
        "mrp": 599
      }
    ],
    "short": "Soft 100% combed-cotton crew-neck tee with a regular fit — an everyday wardrobe essential.",
    "descriptionHtml": "<p>A timeless crew-neck T-shirt cut from breathable 180 GSM combed cotton for all-day comfort. The pre-shrunk fabric holds its shape wash after wash, while the ribbed neckline resists sagging.</p>\n<h3>Product Details</h3>\n<ul>\n<li>Fabric: 100% combed cotton, 180 GSM</li>\n<li>Fit: Regular</li>\n<li>Neck: Ribbed crew neck</li>\n<li>Sleeves: Short sleeves</li>\n<li>Sizes: S, M, L, XL, XXL</li>\n<li>Colour options available</li>\n</ul>\n<h3>Care Instructions</h3>\n<p>Machine wash cold with similar colours. Do not bleach. Tumble dry low. Warm iron if needed.</p>",
    "image": "/img/velora/products/mens-classic-cotton-crew-neck-t-shirt.jpg",
    "images": [
      "/img/velora/products/mens-classic-cotton-crew-neck-t-shirt.jpg"
    ]
  }
];

export const getProduct = (pid) => products.find((p) => p.pid === pid);

// "New Arrivals" on the live home page = the 8 most recently added products.
export const newArrivals = [...products].sort((a, b) => b.wcId - a.wcId).slice(0, 8);

// Live home page "Featured Products" order.
export const featuredProducts = [
  "girls-party-dress",
  "kids-cartoon-print-t-shirt",
  "womens-georgette-printed-saree",
  "womens-floral-print-kurti",
  "mens-bomber-jacket",
  "mens-slim-fit-stretch-denim-jeans",
  "mens-classic-cotton-crew-neck-t-shirt",
].map(getProduct);
