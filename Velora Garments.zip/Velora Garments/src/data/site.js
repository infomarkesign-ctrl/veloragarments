// Business details as shown on https://veloragarments.store
export const site = {
  name: "Velora Garments",
  legalName: "Velora Garments Private Limited",
  tagline: "Premium Clothing for Men, Women & Kids",
  email: "support@veloragarments.store",
  mailto: "mailto:support@veloragarments.store",
  phone: "+91 77158 10075",
  tel: "tel:+917715810075",
  whatsapp: "https://wa.me/917715810075?text=Hello, I would like to know more about your products.",
  hours: "Monday to Saturday, 10:00 AM to 6:00 PM IST",
  topbarLocation: "Goregaon East, Mumbai, Maharashtra",
  address:
    "F-79, First Floor, Express Zone Mall, A Wing, Western Express Highway, Oberoi Garden City (Near Patel Vanika), Mumbai Suburban, Mumbai, Maharashtra – 400063",
  gstin: "27AALCV9644D1ZW",
};
