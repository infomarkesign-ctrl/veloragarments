import { useState } from "react";
import { Link } from "react-router-dom";
import { MAX_QTY, useCart } from "../context/CartContext";

const inr = (n) => n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

export function Amount({ value }) {
  return (
    <span className="woocommerce-Price-amount amount">
      <bdi>
        <span className="woocommerce-Price-currencySymbol">₹</span>
        {inr(value)}
      </bdi>
    </span>
  );
}

// WooCommerce price HTML: a range for variable products, strike-through for simple sale items.
export function PriceTag({ product, as: Tag = "span" }) {
  const hasRange = product.sizes.length > 0 && product.maxPrice !== product.price;
  if (hasRange) {
    return (
      <Tag className="price">
        <Amount value={product.price} /> <span aria-hidden="true">–</span> <Amount value={product.maxPrice} />
      </Tag>
    );
  }
  if (product.originalPrice > product.price) {
    return (
      <Tag className="price">
        <del aria-hidden="true">
          <Amount value={product.originalPrice} />
        </del>{" "}
        <ins aria-hidden="true">
          <Amount value={product.price} />
        </ins>
      </Tag>
    );
  }
  return (
    <Tag className="price">
      <Amount value={product.price} />
    </Tag>
  );
}

const BagIcon = () => (
  <svg width="100" height="100" viewBox="826 826 140 140">
    <path d="M960.758,934.509l2.632,23.541c0.15,1.403-0.25,2.657-1.203,3.761c-0.953,1.053-2.156,1.579-3.61,1.579H833.424c-1.454,0-2.657-0.526-3.61-1.579c-0.952-1.104-1.354-2.357-1.203-3.761l2.632-23.541H960.758z M953.763,871.405l6.468,58.29H831.77l6.468-58.29c0.15-1.203,0.677-2.218,1.58-3.045c0.903-0.827,1.981-1.241,3.234-1.241h19.254v9.627c0,2.658,0.94,4.927,2.82,6.807s4.149,2.82,6.807,2.82c2.658,0,4.926-0.94,6.807-2.82s2.821-4.149,2.821-6.807v-9.627h28.882v9.627c0,2.658,0.939,4.927,2.819,6.807c1.881,1.88,4.149,2.82,6.807,2.82s4.927-0.94,6.808-2.82c1.879-1.88,2.82-4.149,2.82-6.807v-9.627h19.253c1.255,0,2.332,0.414,3.235,1.241C953.086,869.187,953.612,870.202,953.763,871.405z M924.881,857.492v19.254c0,1.304-0.476,2.432-1.429,3.385s-2.08,1.429-3.385,1.429c-1.303,0-2.432-0.477-3.384-1.429c-0.953-0.953-1.43-2.081-1.43-3.385v-19.254c0-5.315-1.881-9.853-5.641-13.613c-3.76-3.761-8.298-5.641-13.613-5.641s-9.853,1.88-13.613,5.641c-3.761,3.76-5.641,8.298-5.641,13.613v19.254c0,1.304-0.476,2.432-1.429,3.385c-0.953,0.953-2.081,1.429-3.384,1.429c-1.304,0-2.432-0.477-3.385-1.429s-1.429-2.081-1.429-3.385v-19.254c0-7.973,2.821-14.779,8.461-20.42c5.641-5.641,12.448-8.461,20.42-8.461c7.973,0,14.779,2.82,20.42,8.461C922.062,842.712,924.881,849.519,924.881,857.492z" />
  </svg>
);

// Astra/WooCommerce product loop item (<li class="product">), same markup as the live shop.
export default function ProductCard({ product, className = "" }) {
  const { items, addToCart } = useCart();
  const [added, setAdded] = useState(false);
  const needsOptions = product.sizes.length > 0;
  const onSale = product.originalPrice > product.price;
  const url = `/product/${product.pid}`;

  const cartQty = items.find((i) => i.pid === product.pid)?.qty ?? 0;
  const maxedOut = !needsOptions && cartQty >= MAX_QTY;

  const handleAddToCart = (e) => {
    e.preventDefault();
    if (maxedOut) return;
    addToCart(product, "", 1);
    setAdded(true);
  };

  const label = needsOptions ? "Select options" : "Add to cart";

  return (
    <li className={`ast-grid-common-col ast-full-width ast-article-post remove-featured-img-padding desktop-align-left tablet-align-left mobile-align-left product type-product status-publish instock has-post-thumbnail ${onSale ? "sale" : ""} purchasable ${needsOptions ? "product-type-variable" : "product-type-simple"} ${className}`}>
      <div className="astra-shop-thumbnail-wrap">
        <Link to={url} className="woocommerce-LoopProduct-link woocommerce-loop-product__link">
          <img
            width="300"
            height="300"
            src={product.thumb || product.image}
            className="attachment-woocommerce_thumbnail size-woocommerce_thumbnail"
            alt={product.name}
            loading="lazy"
          />
        </Link>
        {onSale && <span className="ast-on-card-button ast-onsale-card">Sale!</span>}
        <Link
          to={url}
          onClick={needsOptions ? undefined : handleAddToCart}
          className={`ast-on-card-button ${needsOptions ? "ast-select-options-trigger product_type_variable" : "product_type_simple"} add_to_cart_button`}
          aria-label={`${label} for “${product.name}”`}
        >
          <span className="ast-card-action-tooltip"> {label} </span>
          <span className="ahfb-svg-iconset">
            <span className="ast-icon icon-bag">
              <BagIcon />
            </span>
          </span>
        </Link>
      </div>
      <div className="astra-shop-summary-wrap">
        <span className="ast-woo-product-category">{product.cats?.[0]?.name ?? product.subCategory}</span>
        <Link to={url} className="ast-loop-product__link">
          <h2 className="woocommerce-loop-product__title">{product.name}</h2>
        </Link>
        <PriceTag product={product} />
        {needsOptions ? (
          <Link to={url} className="button product_type_variable add_to_cart_button">
            Select options
          </Link>
        ) : (
          <>
            <a
              href={url}
              onClick={handleAddToCart}
              className={`button product_type_simple add_to_cart_button ajax_add_to_cart${added ? " added" : ""}`}
            >
              {maxedOut ? "Max in cart" : "Add to cart"}
            </a>
            {added && (
              <Link to="/cart" className="added_to_cart wc-forward" title="View cart">
                View cart
              </Link>
            )}
          </>
        )}
      </div>
    </li>
  );
}

// <ul class="products columns-N"> wrapper; Woo uses first/last classes for float clearing.
export function ProductGrid({ products, columns = 4 }) {
  return (
    <ul className={`products columns-${columns}`}>
      {products.map((p, i) => (
        <ProductCard
          key={p.pid}
          product={p}
          className={i % columns === 0 ? "first" : (i + 1) % columns === 0 ? "last" : ""}
        />
      ))}
    </ul>
  );
}
