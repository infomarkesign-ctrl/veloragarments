// Astra page template: container > #primary > article with the entry title + content.
export default function PageShell({ title, children, className = "" }) {
  return (
    <div className="ast-container">
      <div id="primary" className="content-area primary">
        <main id="main" className="site-main">
          <article className={`page type-page status-publish ast-article-single ${className}`}>
            <header className="entry-header ast-no-thumbnail">
              <h1 className="entry-title">{title}</h1>
            </header>
            <div className="entry-content clear" data-ast-blocks-layout="true">
              {children}
            </div>
          </article>
        </main>
      </div>
    </div>
  );
}
