import { Link, NavLink } from "react-router-dom";

// Primary menu, in the same order as the live Astra header.
const menu = [
  { to: "/", label: "Home", end: true },
  { to: "/shop", label: "Shop" },
  { to: "/product-category/men", label: "Men" },
  { to: "/product-category/women", label: "Women" },
  { to: "/product-category/kids", label: "Kids" },
  { to: "/about-us", label: "About Us" },
  { to: "/contact-us", label: "Contact Us" },
  { to: "/cart", label: "Cart" },
  { to: "/checkout", label: "Checkout" },
  { to: "/my-account", label: "Login / Register" },
];

function MenuItems({ onNavigate }) {
  return menu.map((m) => (
    <li key={m.to} className="menu-item">
      <NavLink
        to={m.to}
        end={m.end}
        onClick={onNavigate}
        className="menu-link"
        // Astra highlights the current page via the <li>; mirror that on the link.
        style={({ isActive }) => (isActive ? { color: "var(--velora-wine)" } : undefined)}
      >
        {m.label}
      </NavLink>
    </li>
  ));
}

function Logo() {
  return (
    <div className="ast-builder-layout-element ast-flex site-header-focus-item">
      <div className="site-branding ast-site-identity">
        <span className="site-logo-img">
          <Link to="/" className="custom-logo-link" rel="home">
            <img
              width="106"
              height="70"
              src="/img/wp/logo-106x70.png"
              srcSet="/img/wp/logo-106x70.png 106w, /img/wp/logo-300x197.png 300w"
              sizes="(max-width: 106px) 100vw, 106px"
              className="custom-logo"
              alt="Velora Garments"
            />
          </Link>
        </span>
      </div>
    </div>
  );
}

const MenuIcon = () => (
  <svg className="ast-mobile-svg ast-menu-svg" fill="currentColor" width="24" height="24" viewBox="0 0 24 24">
    <path d="M3 13h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 7h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 19h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1z" />
  </svg>
);

const CloseIcon = () => (
  <svg className="ast-mobile-svg ast-close-svg" fill="currentColor" width="24" height="24" viewBox="0 0 24 24">
    <path d="M5.293 6.707l5.293 5.293-5.293 5.293c-0.391 0.391-0.391 1.024 0 1.414s1.024 0.391 1.414 0l5.293-5.293 5.293 5.293c0.391 0.391 1.024 0.391 1.414 0s0.391-1.024 0-1.414l-5.293-5.293 5.293-5.293c0.391-0.391 0.391-1.024 0-1.414s-1.024-0.391-1.414 0l-5.293 5.293-5.293-5.293c-0.391-0.391-1.024-0.391-1.414 0s-0.391 1.024 0 1.414z" />
  </svg>
);

// Same markup/classes as the Astra header builder on veloragarments.store,
// so public/css/astra.css styles it identically.
export default function Navbar({ mobileOpen, setMobileOpen }) {
  const close = () => setMobileOpen(false);

  return (
    <header className="site-header header-main-layout-1 ast-primary-menu-enabled ast-logo-title-inline ast-hide-custom-menu-mobile ast-builder-menu-toggle-icon ast-mobile-header-inline" id="masthead">
      {/* Desktop header */}
      <div id="ast-desktop-header" data-toggle-type="dropdown">
        <div className="ast-main-header-wrap main-header-bar-wrap">
          <div className="ast-primary-header-bar ast-primary-header main-header-bar site-header-focus-item">
            <div className="site-primary-header-wrap ast-builder-grid-row-container site-header-focus-item ast-container">
              <div className="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
                <div className="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
                  <Logo />
                </div>
                <div className="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
                  <div className="ast-builder-menu-1 ast-builder-menu ast-flex ast-builder-menu-1-focus-item ast-builder-layout-element site-header-focus-item">
                    <div className="ast-main-header-bar-alignment">
                      <div className="main-header-bar-navigation">
                        <nav className="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item" id="primary-site-navigation-desktop" aria-label="Primary Site Navigation">
                          <div className="main-navigation ast-inline-flex">
                            <ul id="ast-hf-menu-1" className="main-header-menu ast-menu-shadow ast-nav-menu ast-flex submenu-with-border stack-on-mobile">
                              <MenuItems />
                            </ul>
                          </div>
                        </nav>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile header */}
      <div id="ast-mobile-header" className="ast-mobile-header-wrap" data-type="dropdown">
        <div className="ast-main-header-wrap main-header-bar-wrap">
          <div className="ast-primary-header-bar ast-primary-header main-header-bar site-primary-header-wrap site-header-focus-item ast-builder-grid-row-layout-default ast-builder-grid-row-tablet-layout-default ast-builder-grid-row-mobile-layout-default">
            <div className="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
              <div className="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
                <Logo />
              </div>
              <div className="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
                <div className="ast-builder-layout-element ast-flex site-header-focus-item">
                  <div className="ast-button-wrap">
                    <button
                      type="button"
                      className={`menu-toggle main-header-menu-toggle ast-mobile-menu-trigger-minimal${mobileOpen ? " toggled" : ""}`}
                      aria-expanded={mobileOpen}
                      aria-label="Main menu toggle"
                      onClick={() => setMobileOpen(!mobileOpen)}
                    >
                      <span className="mobile-menu-toggle-icon">
                        <span aria-hidden="true" className="ahfb-svg-iconset ast-inline-flex svg-baseline">
                          {mobileOpen ? <CloseIcon /> : <MenuIcon />}
                        </span>
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="ast-mobile-header-content content-align-flex-start">
          <div className="ast-builder-menu-mobile ast-builder-menu ast-builder-menu-mobile-focus-item ast-builder-layout-element site-header-focus-item">
            <div className="ast-main-header-bar-alignment">
              <div className={`main-header-bar-navigation${mobileOpen ? " toggle-on" : ""}`}>
                <nav className="site-navigation ast-flex-grow-1 navigation-accessibility" id="ast-mobile-site-navigation" aria-label="Site Navigation">
                  <div id="ast-hf-mobile-menu" className="main-navigation">
                    <ul className="main-header-menu ast-nav-menu ast-flex submenu-with-border astra-menu-animation-fade stack-on-mobile">
                      <MenuItems onNavigate={close} />
                    </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
