import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { site } from "../data/site";

// Astra "below footer" row with the copyright block, as on the live site.
export default function Footer() {
  const [showTop, setShowTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowTop(window.scrollY > 300);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <footer className="site-footer" id="colophon">
        <div className="site-below-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-full ast-builder-grid-row-tablet-full ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack">
          <div className="ast-builder-grid-row-container-inner">
            <div className="ast-builder-footer-grid-columns site-below-footer-inner-wrap ast-builder-grid-row">
              <div className="site-footer-below-section-1 site-footer-section site-footer-section-1">
                <div className="ast-builder-layout-element ast-flex site-footer-focus-item ast-footer-copyright">
                  <div className="ast-footer-copyright">
                    <p>
                      Copyright © {new Date().getFullYear()} Velora Garments
                      <br />
                      GSTIN: {site.gstin}
                      <br />
                      <Link to="/about-us">About</Link> | <Link to="/contact-us">Contact</Link> |{" "}
                      <Link to="/privacy-policy">Privacy Policy</Link> |{" "}
                      <Link to="/terms-and-conditions">Terms &amp; Conditions</Link> |{" "}
                      <Link to="/refund-and-return-policy">Refund &amp; Returns</Link> |{" "}
                      <Link to="/shipping-policy">Shipping</Link> | <Link to="/cancellation-policy">Cancellation</Link>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>

      <div
        id="ast-scroll-top"
        tabIndex={0}
        className="ast-scroll-top-icon ast-scroll-to-top-right"
        data-on-devices="both"
        style={{ display: showTop ? "block" : "none" }}
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        onKeyDown={(e) => e.key === "Enter" && window.scrollTo({ top: 0, behavior: "smooth" })}
      >
        <span className="ast-icon icon-arrow">
          <svg className="ast-arrow-svg" width="26px" height="16.043px" viewBox="57 35.171 26 16.043">
            <path d="M57.5,38.193l12.5,12.5l12.5-12.5l-2.5-2.5l-10,10l-10-10L57.5,38.193z" />
          </svg>
        </span>
        <span className="screen-reader-text">Scroll to Top</span>
      </div>
    </>
  );
}
