// SRPay UPI gateway. Set these in a .env file (see .env.example):
//   VITE_SRPAY_CREATE_ORDER_URL, VITE_SRPAY_API_TOKEN
// Note: VITE_* values are bundled into the client JS, so the token is
// visible to anyone. Move this behind a server-side proxy before going live.
const SRPAY_CREATE_ORDER_URL = import.meta.env.VITE_SRPAY_CREATE_ORDER_URL;
const SRPAY_API_TOKEN = import.meta.env.VITE_SRPAY_API_TOKEN;

export async function createUpiOrder({ amount, name, email, mobile }) {
  if (!SRPAY_CREATE_ORDER_URL || !SRPAY_API_TOKEN) {
    throw new Error("UPI payment is not configured yet. Please choose Cash on Delivery.");
  }

  const res = await fetch(SRPAY_CREATE_ORDER_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_token: SRPAY_API_TOKEN,
      amount,
      name,
      email,
      mobile,
    }),
  });

  let data;
  try {
    data = await res.json();
  } catch {
    throw new Error("Unexpected response from payment gateway");
  }

  if (!res.ok || data.status !== "success" || !data.data?.payment_url) {
    throw new Error(data?.message || "Unable to start UPI payment");
  }

  return data.data;
}
