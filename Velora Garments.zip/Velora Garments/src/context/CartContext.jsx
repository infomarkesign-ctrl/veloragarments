import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { products } from "../data/products";

const CartContext = createContext(null);
const STORAGE_KEY = "velora_cart";
export const MAX_QTY = 10;
const productsById = new Map(products.map((p) => [p.pid, p]));

const lineKey = (pid, size) => `${pid}|${size || ""}`;

// Price for a cart line: variable products are priced per size, as on the live store.
export function linePrice(product, size) {
  const variant = product.sizes.find((s) => s.size === size);
  return variant ? variant.price : product.price;
}

function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    // Re-attach the current product data instead of trusting the snapshot
    // saved at add-time, which can go stale.
    return parsed
      .filter((i) => productsById.has(i.pid))
      .map((i) => {
        const product = productsById.get(i.pid);
        return { ...i, product, price: linePrice(product, i.size) };
      });
  } catch {
    return [];
  }
}

export function CartProvider({ children }) {
  const [items, setItems] = useState(loadCart);

  useEffect(() => {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(items.map(({ key, pid, size, qty }) => ({ key, pid, size, qty })))
    );
  }, [items]);

  const addToCart = (product, size = "", qty = 1) => {
    const key = lineKey(product.pid, size);
    const existing = items.find((i) => i.key === key);
    const nextQty = Math.min((existing?.qty ?? 0) + qty, MAX_QTY);
    const limited = nextQty < (existing?.qty ?? 0) + qty;

    setItems((prev) => {
      if (prev.some((i) => i.key === key)) {
        return prev.map((i) => (i.key === key ? { ...i, qty: nextQty } : i));
      }
      return [
        ...prev,
        { key, pid: product.pid, size, product, price: linePrice(product, size), qty: nextQty },
      ];
    });

    return { limited, maxQty: MAX_QTY };
  };

  const removeFromCart = (key) => {
    setItems((prev) => prev.filter((i) => i.key !== key));
  };

  const updateQty = (key, qty) => {
    if (qty < 1) return { limited: false };
    const nextQty = Math.min(qty, MAX_QTY);
    setItems((prev) => prev.map((i) => (i.key === key ? { ...i, qty: nextQty } : i)));
    return { limited: nextQty < qty, maxQty: MAX_QTY };
  };

  const clearCart = () => setItems([]);

  const totalCount = useMemo(() => items.reduce((sum, i) => sum + i.qty, 0), [items]);

  const subtotal = useMemo(() => items.reduce((sum, i) => sum + i.qty * i.price, 0), [items]);

  const value = {
    items,
    addToCart,
    removeFromCart,
    updateQty,
    clearCart,
    totalCount,
    subtotal,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within a CartProvider");
  return ctx;
}
