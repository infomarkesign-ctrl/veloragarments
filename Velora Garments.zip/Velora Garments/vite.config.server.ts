import { defineConfig } from "vite";

export default defineConfig({
  build: {
    ssr: "server/node-build.ts",
    outDir: "dist/server",
    rollupOptions: {
      external: ["better-sqlite3", "dotenv", "express", "cors", "nodemailer"],
      output: {
        entryFileNames: "[name].mjs",
      },
    },
  },
});
